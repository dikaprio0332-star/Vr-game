# Joy-Con VR для Android — без Unity

Тот же проект (2 Joy-Con по L2CAP-Bluetooth, калибровка, трекинг рук маркерами
через ARCore, комплементарный фильтр, стерео-VR), но как обычное Android Studio
Kotlin-приложение. Никакого Unity Editor, никакой лицензии/аккаунта,
`UNITY_LICENSE`/`UNITY_EMAIL`/`UNITY_PASSWORD` в CI больше не нужны — сборка
это просто `gradle assembleDebug`.

## Что изменилось

| Было (Unity) | Стало (нативный Android) |
|---|---|
| C# скрипты в `Assets/Scripts/**` | Kotlin в `app/src/main/java/com/joyconvr/**`, логика портирована 1:1 |
| `UnityEngine.Vector3`/`Quaternion` | Свои `math/Vec3.kt`, `math/Quat.kt` (пара десятков строк) |
| ARFoundation (`ARTrackedImageManager`) | Официальный ARCore SDK для Android напрямую (`com.google.ar.core.Session`/`AugmentedImage`) |
| `JoyConManager.cs` + `AndroidJavaObject`-рефлексия | `joycon/JoyConManager.kt` — прямые вызовы, без reflection и без `UnitySendMessage` |
| `JoyConUnityBridge.kt` (шлёт JSON в Unity) | Слит в `JoyConManager.kt` — колбэки напрямую как Kotlin-интерфейс |
| `JoyConDevice.kt`, `JoyConInputReport.kt` | **Без изменений по сути** — этот код и раньше не касался Unity |
| Google Cardboard XR Plugin for Unity | Простой side-by-side стерео-рендер в `vr/StereoRenderer.kt` (см. ограничение ниже) |
| `game-ci/unity-builder` + Unity-секреты в CI | Обычный `gradle assembleDebug` в `build-android.yml` |

## Честные ограничения (как и в исходном README)

1. **Изображения маркеров нужно добавить самому.** В проекте, как и раньше,
   есть только инструкции по печати (`app/src/main/assets/markers/*.md`), но
   не сами PNG. Положите напечатанные картинки как
   `app/src/main/assets/markers/left_marker.png` и `right_marker.png` —
   без них `AugmentedImageDatabase` пустая и ARCore честно ничего не трекает.
2. **`StereoRenderer.kt` — рендер без коррекции линзы.** Это простой
   side-by-side вывод в две половины экрана с кубиком-маркером руки в каждой,
   без barrel-дисторсии под конкретную дешёвую VR-оправу. Если нужна
   правильная геометрия под линзы — подключите `com.google.ar.core:cardboard`
   (тоже официальный, бесплатный, без лицензии) вместо своего рендерера;
   код трекинга Joy-Con/рук от этого не меняется.
3. **Рендер фона камеры и куб руки — заглушки-комментарии в `StereoRenderer.kt`**
   (`CameraBackgroundRenderer.draw()`, `HandCubeRenderer`). Это обычный
   OpenGL ES 2.0 бойлерплейт (шейдеры + буфер вершин), не имеющий отношения
   к самой миграции с Unity — я оставил его как явный TODO, а не притворился,
   что он готов. Готовый пример фона камеры есть в официальных сэмплах
   ARCore SDK (`BackgroundRenderer.java`), можно перенести почти дословно.
4. **Я не собирал и не тестировал этот APK** — в этой среде нет Android SDK.
   Откройте `JoyConVRAndroid/` в Android Studio (Kotlin, ARCore — всё есть в
   build.gradle) и соберите/запустите на устройстве.
5. **Gradle wrapper не закоммичен** (не было сети, чтобы скачать
   `gradle-wrapper.jar`). Один раз локально: `gradle wrapper --gradle-version 8.7`,
   закоммитьте `gradlew`, `gradlew.bat`, `gradle/wrapper/*` — тогда и CI, и
   локальная сборка смогут использовать `./gradlew`. До этого CI использует
   `gradle/actions/setup-gradle`, тоже работает без wrapper.
6. Требования к телефону те же: **ARCore-совместимое устройство**, **Android
   10 (API 29)+** для L2CAP.

## Структура

```
app/src/main/java/com/joyconvr/
  MainActivity.kt              # разрешения, ARCore Session, склейка всего
  joycon/
    JoyConDevice.kt             # L2CAP-соединение с одним Joy-Con (как было)
    JoyConInputReport.kt        # разбор input report 0x30 (как было)
    JoyConManager.kt            # было JoyConUnityBridge.kt + JoyConManager.cs
  calibration/JoyConCalibration.kt
  fusion/ComplementaryFilter.kt
  fusion/MarkerHandTracker.kt   # ARCore AugmentedImage напрямую
  vr/VRHandController.kt
  vr/StereoRenderer.kt          # GLSurfaceView.Renderer, стерео + камера-фон
  ui/CalibrationUiController.kt
  math/Vec3.kt, Quat.kt
app/src/main/assets/markers/    # инструкции по печати маркеров (без PNG)
build-android.yml               # новый CI: gradle assembleDebug, без Unity
```
