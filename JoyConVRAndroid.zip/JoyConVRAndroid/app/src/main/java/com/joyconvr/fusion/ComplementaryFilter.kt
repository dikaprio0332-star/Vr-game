package com.joyconvr.fusion

import com.joyconvr.math.Quat
import com.joyconvr.math.Vec3

/**
 * Complementary filter, ported 1:1 from ComplementaryFilter.cs: the Joy-Con gyro is integrated
 * every frame (fast, ~60-200Hz over BT, but orientation-only and it drifts), the camera marker
 * gives infrequent (ARCore frame rate, usually 30-60Hz, with processing latency and dropouts on
 * occlusion) absolute pose corrections. Result: orientation = gyro/marker blend weighted by
 * alpha, position = marker pose (camera gives absolute position; double-integrating accelerometer
 * for position is unreliable on MEMS sensors and is intentionally not used here).
 */
class ComplementaryFilter {

    /**
     * Trust weight given to the gyro at each marker correction. Closer to 1 = smoother but more
     * accumulated drift between marker frames. Closer to 0 = snaps to the marker harder, less
     * drift but more visible camera jitter.
     */
    var orientationAlpha: Float = 0.92f

    private var fusedOrientation = Quat.IDENTITY
    private var fusedPosition = Vec3.ZERO
    private var initializedFlag = false
    private var lastMarkerTimestamp = -1f

    /** Call every frame with calibrated gyro (deg/s) and dt. */
    fun integrateGyro(gyroDegPerSecond: Vec3, dt: Float) {
        if (!initializedFlag) return
        val delta = Quat.fromEulerDegrees(gyroDegPerSecond * dt)
        fusedOrientation = fusedOrientation * delta
    }

    /** Call on every new valid marker tracking update (ARCore AugmentedImage). */
    fun correctWithMarker(markerPosition: Vec3, markerRotation: Quat, timestamp: Float) {
        if (!initializedFlag) {
            fusedPosition = markerPosition
            fusedOrientation = markerRotation
            initializedFlag = true
            lastMarkerTimestamp = timestamp
            return
        }

        // Position comes entirely from the marker — no invented "virtual" precision.
        fusedPosition = markerPosition

        // Orientation is a complementary blend: between marker updates we've already drifted
        // via the gyro, so we slerp rather than hard-overwrite.
        fusedOrientation = Quat.slerp(markerRotation, fusedOrientation, orientationAlpha)

        lastMarkerTimestamp = timestamp
    }

    fun hasMarkerRecently(now: Float, maxAgeSeconds: Float = 1.5f): Boolean =
        lastMarkerTimestamp >= 0 && (now - lastMarkerTimestamp) <= maxAgeSeconds

    val position: Vec3 get() = fusedPosition
    val rotation: Quat get() = fusedOrientation
    val initialized: Boolean get() = initializedFlag

    fun reset() {
        initializedFlag = false
        fusedOrientation = Quat.IDENTITY
        fusedPosition = Vec3.ZERO
        lastMarkerTimestamp = -1f
    }
}
