package com.joyconvr

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Main menu — the app's launcher screen. Lets the user start the MR (mixed-reality passthrough)
 * session on demand, instead of jumping straight into the camera/Joy-Con session on app launch.
 */
class MenuActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        findViewById<android.widget.Button>(R.id.startMrButton).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}
