package com.joyconvr.joycon

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.util.Log
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/**
 * Одно L2CAP-соединение с одним Joy-Con (Left или Right).
 *
 * Протокол: BluetoothDevice.createInsecureL2capChannel(psm) — публичный
 * Android API с API 29 (Android 10). PSM 0x11 = control, 0x13 = interrupt —
 * это стандартные Bluetooth HID PSM-номера; на них Joy-Con отвечает своим
 * собственным (не-HID-совместимым по содержимому) протоколом, задокументированным
 * реверс-инженерами в проекте dekuNukem/Nintendo_Switch_Reverse_Engineering.
 *
 * ВАЖНО: точные байтовые офсеты калибровки во flash (SPI read, subcommand 0x10)
 * приведены по открытой документации по памяти и МОГУТ отличаться на 1-2 байта
 * от актуальной ревизии прошивки — перед продакшеном сверьте с текущей версией
 * репозитория dekuNukem. Поэтому в проекте есть независимый от этих офсетов
 * runtime-калибровщик (см. JoyConCalibration.cs) — он не доверяет фабричным
 * данным слепо, а сам меряет смещение гироскопа в состоянии покоя.
 */
class JoyConDevice(
    private val device: BluetoothDevice,
    private val side: Side,
    private val listener: Listener
) {
    enum class Side { LEFT, RIGHT }

    interface Listener {
        fun onConnected(side: Side)
        fun onDisconnected(side: Side, reason: String)
        fun onInputReport(side: Side, report: JoyConInputReport)
        fun onCalibrationRaw(side: Side, address: Int, data: ByteArray)
        fun onError(side: Side, message: String)
    }

    companion object {
        private const val TAG = "JoyConDevice"
        private const val PSM_CONTROL = 0x11
        private const val PSM_INTERRUPT = 0x13
    }

    private var controlSocket: BluetoothSocket? = null
    private var interruptSocket: BluetoothSocket? = null
    private var controlOut: OutputStream? = null
    private var interruptIn: InputStream? = null
    private var interruptOut: OutputStream? = null
    @Volatile private var running = false
    private val packetCounter = AtomicInteger(0)

    fun connect() {
        thread(name = "joycon-connect-$side") {
            try {
                controlSocket = device.createInsecureL2capChannel(PSM_CONTROL)
                controlSocket!!.connect()
                controlOut = controlSocket!!.outputStream

                interruptSocket = device.createInsecureL2capChannel(PSM_INTERRUPT)
                interruptSocket!!.connect()
                interruptIn = interruptSocket!!.inputStream
                interruptOut = interruptSocket!!.outputStream

                running = true
                listener.onConnected(side)

                performHandshake()
                readLoop()
            } catch (e: IOException) {
                listener.onError(side, "L2CAP connect failed: ${e.message}")
                disconnect("connect_failed")
            }
        }
    }

    /** Включаем полноценный режим 0x30 (60Гц, с IMU) и сам IMU. */
    private fun performHandshake() {
        // 1. Запрашиваем инфо об устройстве — заодно "будим" протокол
        sendSubcommand(0x02, ByteArray(0))
        Thread.sleep(50)

        // 2. Включаем IMU (гироскоп+акселерометр)
        sendSubcommand(0x40, byteArrayOf(0x01))
        Thread.sleep(50)

        // 3. Переключаем режим отчётов на 0x30 — standard full mode, 60Гц, с IMU-сэмплами
        sendSubcommand(0x03, byteArrayOf(0x30))
        Thread.sleep(50)

        // 4. Читаем заводскую калибровку IMU из SPI-флеша (best-effort, см. предупреждение выше)
        requestSpiRead(0x6020, 24)
        Thread.sleep(30)

        // 5. Включаем вибро (не обязательно для трекинга, но полезно для UX-обратной связи)
        sendSubcommand(0x48, byteArrayOf(0x01))
    }

    fun requestSpiRead(address: Int, length: Int) {
        val data = ByteArray(5)
        data[0] = (address and 0xFF).toByte()
        data[1] = ((address shr 8) and 0xFF).toByte()
        data[2] = ((address shr 16) and 0xFF).toByte()
        data[3] = ((address shr 24) and 0xFF).toByte()
        data[4] = length.toByte()
        sendSubcommand(0x10, data)
    }

    fun setPlayerLights(mask: Int) {
        sendSubcommand(0x30, byteArrayOf(mask.toByte()))
    }

    fun sendRumble(amplitude: Float) {
        // Простое (не HD) рамбл-письмо через rumble-байты output report 0x10
        val out = controlOut ?: return
        val packet = ByteArray(10)
        packet[0] = 0x10
        packet[1] = nextPacketNumber()
        val enc = encodeSimpleRumble(amplitude)
        System.arraycopy(enc, 0, packet, 2, 8)
        try {
            out.write(packet)
        } catch (e: IOException) {
            listener.onError(side, "rumble write failed: ${e.message}")
        }
    }

    private fun encodeSimpleRumble(amplitude: Float): ByteArray {
        // Нейтральное рамбл-кодирование (не HD-точное, но реально воспринимаемое устройством)
        val a = amplitude.coerceIn(0f, 1f)
        val hf: Byte = if (a > 0f) 0x40.toByte() else 0x00
        val hfAmp: Byte = (a * 0x64).toInt().toByte()
        val lf: Byte = 0x40
        val lfAmp: Byte = (a * 0x64).toInt().toByte()
        return byteArrayOf(hf, hfAmp, lf, lfAmp, hf, hfAmp, lf, lfAmp)
    }

    private fun sendSubcommand(subcommand: Int, data: ByteArray) {
        val out = controlOut ?: return
        val packet = ByteArray(11 + data.size)
        packet[0] = 0x01
        packet[1] = nextPacketNumber()
        // байты 2..9 — нейтральный рамбл (обязателен в каждом output report 0x01)
        val neutralRumble = byteArrayOf(
            0x00, 0x01, 0x40, 0x40,
            0x00, 0x01, 0x40, 0x40
        )
        System.arraycopy(neutralRumble, 0, packet, 2, 8)
        packet[10] = subcommand.toByte()
        System.arraycopy(data, 0, packet, 11, data.size)
        try {
            out.write(packet)
        } catch (e: IOException) {
            listener.onError(side, "subcommand write failed: ${e.message}")
        }
    }

    private fun nextPacketNumber(): Byte =
        (packetCounter.getAndIncrement() and 0x0F).toByte()

    private fun readLoop() {
        val input = interruptIn ?: return
        val buffer = ByteArray(362) // максимальный размер input report Joy-Con с очередями
        try {
            while (running) {
                val len = input.read(buffer)
                if (len <= 0) continue
                handleReport(buffer, len)
            }
        } catch (e: IOException) {
            if (running) {
                listener.onError(side, "read loop failed: ${e.message}")
                disconnect("read_error")
            }
        }
    }

    private fun handleReport(buffer: ByteArray, length: Int) {
        if (length < 1) return
        when (buffer[0].toInt() and 0xFF) {
            0x30, 0x31, 0x32, 0x33 -> {
                // Standard full mode: кнопки/стики/IMU
                val report = JoyConInputReport.parse(buffer, length, side)
                if (report != null) listener.onInputReport(side, report)
            }
            0x21 -> {
                // Ответ на подкоманду — в т.ч. результат SPI read (0x10) и device info (0x02)
                handleSubcommandReply(buffer, length)
            }
            else -> {
                // Прочие report ID (0x23 NFC/IR и т.п.) в этом проекте не используются
            }
        }
    }

    private fun handleSubcommandReply(buffer: ByteArray, length: Int) {
        if (length < 14) return
        val ackByte = buffer[13].toInt() and 0xFF
        val subcommandId = buffer[14].toInt() and 0xFF
        if (subcommandId == 0x10 && length >= 20 + 24) {
            // Ответ на SPI read: байты 15-18 = адрес (LE), 19 = длина, 20.. = данные
            val address = (buffer[15].toInt() and 0xFF) or
                ((buffer[16].toInt() and 0xFF) shl 8) or
                ((buffer[17].toInt() and 0xFF) shl 16) or
                ((buffer[18].toInt() and 0xFF) shl 24)
            val dataLen = buffer[19].toInt() and 0xFF
            if (20 + dataLen <= length) {
                val data = buffer.copyOfRange(20, 20 + dataLen)
                listener.onCalibrationRaw(side, address, data)
            }
        }
    }

    fun disconnect(reason: String) {
        if (!running && controlSocket == null && interruptSocket == null) return
        running = false
        try { controlSocket?.close() } catch (_: IOException) {}
        try { interruptSocket?.close() } catch (_: IOException) {}
        controlSocket = null
        interruptSocket = null
        listener.onDisconnected(side, reason)
    }
}
