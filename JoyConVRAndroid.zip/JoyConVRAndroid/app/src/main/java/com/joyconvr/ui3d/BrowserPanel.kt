package com.joyconvr.ui3d

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/**
 * A floating "browser window" for the MR scene (visionOS-style panel): a real WebView, captured
 * into a bitmap and drawn on a 3D quad (see UiPanelRenderer + StereoRenderer's world-anchored
 * panel), with a small toolbar (back / home) and click dispatch driven by the tracked hand
 * cursor + Joy-Con trigger.
 *
 * Honest limitation: the WebView is captured via `View.draw()` on a ~15fps timer rather than a
 * live hardware-composited feed — smooth enough for reading/browsing, not for video playback.
 */
class BrowserPanel(activity: Activity, container: ViewGroup) {

    companion object {
        const val CONTENT_WIDTH_PX = 1024
        const val CONTENT_HEIGHT_PX = 640
        const val TOOLBAR_HEIGHT_PX = 88
        const val TOTAL_WIDTH_PX = CONTENT_WIDTH_PX
        const val TOTAL_HEIGHT_PX = CONTENT_HEIGHT_PX + TOOLBAR_HEIGHT_PX
        const val HOME_URL = "https://www.google.com"

        private const val BACK_LEFT = 16f
        private const val BACK_RIGHT = 140f
        private const val HOME_LEFT = 160f
        private const val HOME_RIGHT = 320f
    }

    /** Whether the panel is currently shown in the MR scene. */
    @Volatile var isVisible: Boolean = false
        private set

    /** Bumped every time the bitmap is redrawn, so the GL thread knows when to re-upload it. */
    @Volatile var contentVersion: Int = 0
        private set

    val aspectRatio: Float get() = TOTAL_WIDTH_PX.toFloat() / TOTAL_HEIGHT_PX.toFloat()

    private val webView: WebView = WebView(activity)
    private val bitmap = Bitmap.createBitmap(TOTAL_WIDTH_PX, TOTAL_HEIGHT_PX, Bitmap.Config.ARGB_8888)
    private val bitmapCanvas = Canvas(bitmap)
    private val lock = Any()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var currentUrl = HOME_URL

    private val toolbarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0x20, 0x20, 0x28) }
    private val toolbarTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 30f
    }
    private val urlTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0xAA, 0xAA, 0xAA)
        textSize = 24f
    }
    private val buttonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0x38, 0x38, 0x44) }

    private val refreshLoop = object : Runnable {
        override fun run() {
            if (isVisible) captureFrame()
            mainHandler.postDelayed(this, 66L) // ~15fps is plenty for a UI panel
        }
    }

    init {
        webView.layoutParams = FrameLayout.LayoutParams(CONTENT_WIDTH_PX, CONTENT_HEIGHT_PX)
        // Kept attached (so its Chromium compositor actually initializes) but pushed off-screen
        // and invisible — we drive it entirely by manual draw() calls into our own bitmap.
        webView.visibility = View.INVISIBLE
        webView.translationX = -100000f
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                currentUrl = url ?: currentUrl
                captureFrame()
            }
        }
        container.addView(webView)
        webView.measure(
            View.MeasureSpec.makeMeasureSpec(CONTENT_WIDTH_PX, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(CONTENT_HEIGHT_PX, View.MeasureSpec.EXACTLY)
        )
        webView.layout(0, 0, CONTENT_WIDTH_PX, CONTENT_HEIGHT_PX)
        webView.loadUrl(HOME_URL)
        mainHandler.post(refreshLoop)
    }

    fun toggle() { if (isVisible) hide() else show() }

    fun show() {
        isVisible = true
        mainHandler.post { captureFrame() }
    }

    fun hide() { isVisible = false }

    fun goHome() = mainHandler.post { webView.loadUrl(HOME_URL) }
    fun goBack() = mainHandler.post { if (webView.canGoBack()) webView.goBack() }

    /** Thread-safe snapshot for the GL thread (call from the GL thread). */
    fun snapshot(): Bitmap = synchronized(lock) { bitmap }

    /**
     * Handles a "tap" from the tracked hand cursor touching the panel. u,v are normalized
     * 0..1, origin top-left of the whole panel (toolbar + content).
     */
    fun handleTap(u: Float, v: Float) {
        val px = (u * TOTAL_WIDTH_PX).coerceIn(0f, TOTAL_WIDTH_PX - 1f)
        val py = (v * TOTAL_HEIGHT_PX).coerceIn(0f, TOTAL_HEIGHT_PX - 1f)

        if (py <= TOOLBAR_HEIGHT_PX) {
            when (px) {
                in BACK_LEFT..BACK_RIGHT -> goBack()
                in HOME_LEFT..HOME_RIGHT -> goHome()
            }
            return
        }
        val contentX = px
        val contentY = py - TOOLBAR_HEIGHT_PX
        mainHandler.post { dispatchClick(contentX, contentY) }
    }

    private fun dispatchClick(x: Float, y: Float) {
        val downTime = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, x, y, 0)
        val up = MotionEvent.obtain(downTime, downTime + 40, MotionEvent.ACTION_UP, x, y, 0)
        webView.dispatchTouchEvent(down)
        webView.dispatchTouchEvent(up)
        down.recycle()
        up.recycle()
        captureFrame()
    }

    private fun captureFrame() {
        synchronized(lock) {
            bitmapCanvas.drawColor(Color.rgb(0x10, 0x10, 0x14))
            bitmapCanvas.save()
            bitmapCanvas.translate(0f, TOOLBAR_HEIGHT_PX.toFloat())
            webView.draw(bitmapCanvas)
            bitmapCanvas.restore()

            // Toolbar chrome, drawn on top of the page snapshot.
            bitmapCanvas.drawRect(0f, 0f, TOTAL_WIDTH_PX.toFloat(), TOOLBAR_HEIGHT_PX.toFloat(), toolbarPaint)
            bitmapCanvas.drawRoundRect(RectF(BACK_LEFT, 16f, BACK_RIGHT, TOOLBAR_HEIGHT_PX - 16f), 12f, 12f, buttonPaint)
            bitmapCanvas.drawText("<", 68f, TOOLBAR_HEIGHT_PX / 2f + 10f, toolbarTextPaint)
            bitmapCanvas.drawRoundRect(RectF(HOME_LEFT, 16f, HOME_RIGHT, TOOLBAR_HEIGHT_PX - 16f), 12f, 12f, buttonPaint)
            bitmapCanvas.drawText("Home", 190f, TOOLBAR_HEIGHT_PX / 2f + 10f, toolbarTextPaint)
            bitmapCanvas.drawText(currentUrl, 344f, TOOLBAR_HEIGHT_PX / 2f + 8f, urlTextPaint)
        }
        contentVersion++
    }
}
