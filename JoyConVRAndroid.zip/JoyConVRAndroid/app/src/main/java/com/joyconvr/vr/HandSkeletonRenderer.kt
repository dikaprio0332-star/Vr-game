package com.joyconvr.vr

import android.opengl.GLES20
import android.opengl.Matrix
import com.joyconvr.math.Quat
import com.joyconvr.math.Vec3

/**
 * Draws a simple stick-figure hand skeleton (wrist -> palm -> 5 finger chains) at a tracked
 * hand's pose, as the in-world marker for that hand — replaces the old placeholder cube.
 *
 * The individual finger joints are not actually tracked (only one rigid pose per hand comes out
 * of the marker + gyro fusion filter), so the skeleton is authored once in a relaxed open-hand
 * shape, local to the wrist, and rendered as a single rigid unit with the tracked position and
 * rotation applied.
 */
class HandSkeletonRenderer {
    private var program = 0
    private var positionAttrib = 0
    private var mvpUniform = 0
    private var colorUniform = 0

    private val segments = skeletonSegments()
    private val vertexBuffer = directFloatBuffer(segments)
    private val vertexCount = segments.size / 3

    fun createOnGlThread() {
        program = linkProgram(
            """
            uniform mat4 u_MVP;
            attribute vec4 a_Position;
            void main() {
                gl_Position = u_MVP * a_Position;
            }
            """.trimIndent(),
            """
            precision mediump float;
            uniform vec4 u_Color;
            void main() {
                gl_FragColor = u_Color;
            }
            """.trimIndent()
        )
        positionAttrib = GLES20.glGetAttribLocation(program, "a_Position")
        mvpUniform = GLES20.glGetUniformLocation(program, "u_MVP")
        colorUniform = GLES20.glGetUniformLocation(program, "u_Color")
    }

    /** Draws the skeleton at [position]/[rotation] (world space, meters/quaternion). */
    fun draw(projection: FloatArray, view: FloatArray, position: Vec3, rotation: Quat, r: Float, g: Float, b: Float) {
        val translation = FloatArray(16)
        Matrix.setIdentityM(translation, 0)
        Matrix.translateM(translation, 0, position.x, position.y, position.z)

        val model = FloatArray(16)
        Matrix.multiplyMM(model, 0, translation, 0, rotation.toMatrix(), 0)

        val viewModel = FloatArray(16)
        Matrix.multiplyMM(viewModel, 0, view, 0, model, 0)
        val mvp = FloatArray(16)
        Matrix.multiplyMM(mvp, 0, projection, 0, viewModel, 0)

        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(mvpUniform, 1, false, mvp, 0)
        GLES20.glUniform4f(colorUniform, r, g, b, 1f)
        GLES20.glLineWidth(4f)

        vertexBuffer.position(0)
        GLES20.glVertexAttribPointer(positionAttrib, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer)
        GLES20.glEnableVertexAttribArray(positionAttrib)
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, vertexCount)
        GLES20.glDisableVertexAttribArray(positionAttrib)
    }

    private companion object {
        /**
         * Bone list as (start, end) point pairs, in meters, local to the wrist at the origin,
         * palm facing +Z, fingers spreading along X, "back of hand" toward +Y. Flattened to a
         * flat x,y,z,x,y,z,... array of GL_LINES vertices (each consecutive pair = one segment).
         */
        fun skeletonSegments(): FloatArray {
            val wrist = Vec3(0f, 0f, 0f)
            val palm = Vec3(0f, 0f, 0.03f)

            val thumbBase = Vec3(-0.035f, 0.002f, 0.025f)
            val indexBase = Vec3(-0.018f, 0f, 0.045f)
            val middleBase = Vec3(-0.004f, 0f, 0.048f)
            val ringBase = Vec3(0.010f, 0f, 0.045f)
            val pinkyBase = Vec3(0.024f, 0f, 0.038f)

            val thumbMid = Vec3(-0.045f, 0.006f, 0.040f)
            val thumbTip = Vec3(-0.050f, 0.010f, 0.052f)

            val indexMid = Vec3(-0.020f, 0.002f, 0.065f)
            val indexTip = Vec3(-0.021f, 0.003f, 0.080f)

            val middleMid = Vec3(-0.004f, 0.002f, 0.070f)
            val middleTip = Vec3(-0.004f, 0.003f, 0.088f)

            val ringMid = Vec3(0.012f, 0.002f, 0.066f)
            val ringTip = Vec3(0.013f, 0.003f, 0.082f)

            val pinkyMid = Vec3(0.028f, 0.002f, 0.054f)
            val pinkyTip = Vec3(0.030f, 0.003f, 0.066f)

            val bones = listOf(
                wrist to palm,
                palm to thumbBase,
                palm to indexBase,
                palm to middleBase,
                palm to ringBase,
                palm to pinkyBase,
                thumbBase to thumbMid, thumbMid to thumbTip,
                indexBase to indexMid, indexMid to indexTip,
                middleBase to middleMid, middleMid to middleTip,
                ringBase to ringMid, ringMid to ringTip,
                pinkyBase to pinkyMid, pinkyMid to pinkyTip
            )

            val flat = FloatArray(bones.size * 2 * 3)
            var i = 0
            for ((a, b) in bones) {
                flat[i++] = a.x; flat[i++] = a.y; flat[i++] = a.z
                flat[i++] = b.x; flat[i++] = b.y; flat[i++] = b.z
            }
            return flat
        }
    }
}
