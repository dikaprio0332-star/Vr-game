package com.joyconvr.math

import kotlin.math.*

/** Replaces UnityEngine.Quaternion — just the handful of operations this project needs. */
data class Quat(val x: Float = 0f, val y: Float = 0f, val z: Float = 0f, val w: Float = 1f) {

    /** Quaternion multiplication: this * o (apply o first, then this — same convention as Unity's `a * b`). */
    operator fun times(o: Quat): Quat = Quat(
        w * o.x + x * o.w + y * o.z - z * o.y,
        w * o.y - x * o.z + y * o.w + z * o.x,
        w * o.z + x * o.y - y * o.x + z * o.w,
        w * o.w - x * o.x - y * o.y - z * o.z
    )

    fun normalized(): Quat {
        val len = sqrt(x * x + y * y + z * z + w * w)
        return if (len > 1e-6f) Quat(x / len, y / len, z / len, w / len) else IDENTITY
    }

    /** Column-major 4x4 rotation matrix (android.opengl.Matrix layout), translation left at 0. */
    fun toMatrix(): FloatArray {
        val xx = x * x; val yy = y * y; val zz = z * z
        val xy = x * y; val xz = x * z; val yz = y * z
        val wx = w * x; val wy = w * y; val wz = w * z
        return floatArrayOf(
            1f - 2f * (yy + zz), 2f * (xy + wz), 2f * (xz - wy), 0f,
            2f * (xy - wz), 1f - 2f * (xx + zz), 2f * (yz + wx), 0f,
            2f * (xz + wy), 2f * (yz - wx), 1f - 2f * (xx + yy), 0f,
            0f, 0f, 0f, 1f
        )
    }

    companion object {
        val IDENTITY = Quat(0f, 0f, 0f, 1f)

        /** Builds a rotation from Euler angles given in degrees/second * dt (small-angle gyro integration). */
        fun fromEulerDegrees(v: Vec3): Quat {
            val rx = Math.toRadians(v.x.toDouble()) / 2.0
            val ry = Math.toRadians(v.y.toDouble()) / 2.0
            val rz = Math.toRadians(v.z.toDouble()) / 2.0
            val qx = Quat(sin(rx).toFloat(), 0f, 0f, cos(rx).toFloat())
            val qy = Quat(0f, sin(ry).toFloat(), 0f, cos(ry).toFloat())
            val qz = Quat(0f, 0f, sin(rz).toFloat(), cos(rz).toFloat())
            // Same ZXY-ish composition order UnityEngine.Quaternion.Euler effectively yields for small angles.
            return (qz * qy * qx).normalized()
        }

        /** Spherical linear interpolation, a -> b, t in [0,1]. */
        fun slerp(a: Quat, b: Quat, t: Float): Quat {
            var bx = b.x; var by = b.y; var bz = b.z; var bw = b.w
            var cosHalfTheta = a.x * bx + a.y * by + a.z * bz + a.w * bw
            if (cosHalfTheta < 0) { bx = -bx; by = -by; bz = -bz; bw = -bw; cosHalfTheta = -cosHalfTheta }
            if (cosHalfTheta > 0.9995f) {
                return Quat(
                    a.x + t * (bx - a.x), a.y + t * (by - a.y),
                    a.z + t * (bz - a.z), a.w + t * (bw - a.w)
                ).normalized()
            }
            val halfTheta = acos(cosHalfTheta)
            val sinHalfTheta = sqrt(1f - cosHalfTheta * cosHalfTheta)
            val ratioA = sin((1 - t) * halfTheta) / sinHalfTheta
            val ratioB = sin(t * halfTheta) / sinHalfTheta
            return Quat(
                a.x * ratioA + bx * ratioB, a.y * ratioA + by * ratioB,
                a.z * ratioA + bz * ratioB, a.w * ratioA + bw * ratioB
            ).normalized()
        }
    }
}
