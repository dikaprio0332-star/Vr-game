package com.joyconvr.ui

import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import com.joyconvr.R
import com.joyconvr.calibration.JoyConCalibration
import com.joyconvr.joycon.JoyConDevice

/** Ported from CalibrationUI.cs — same event wiring, plain Android widgets instead of uGUI. */
class CalibrationUiController(
    private val calibration: JoyConCalibration,
    private val statusText: TextView,
    private val progressLeft: ProgressBar,
    private val progressRight: ProgressBar,
    startButton: Button
) {
    init {
        calibration.onCalibrationStarted = { side ->
            statusText.setText(if (side == JoyConDevice.Side.LEFT) R.string.hold_still_left else R.string.hold_still_right)
        }
        calibration.onCalibrationProgress = { side, t -> handleProgress(side, t) }
        calibration.onCalibrationFinished = { side ->
            statusText.setText(if (side == JoyConDevice.Side.LEFT) R.string.calibrated_left else R.string.calibrated_right)
        }
        startButton.setOnClickListener { startBoth() }
    }

    private fun startBoth() {
        calibration.startCalibration(JoyConDevice.Side.LEFT)
        calibration.startCalibration(JoyConDevice.Side.RIGHT)
    }

    private fun handleProgress(side: JoyConDevice.Side, t: Float) {
        val bar = if (side == JoyConDevice.Side.LEFT) progressLeft else progressRight
        bar.progress = (t * 100).toInt()
    }
}
