package com.joyconvr.math

import kotlin.math.sqrt

/** Replaces UnityEngine.Vector3 — no engine, so we own the (tiny) math ourselves. */
data class Vec3(val x: Float = 0f, val y: Float = 0f, val z: Float = 0f) {
    operator fun plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Float) = Vec3(x * s, y * s, z * s)
    operator fun div(s: Float) = Vec3(x / s, y / s, z / s)

    val length: Float get() = sqrt(x * x + y * y + z * z)
    val normalized: Vec3 get() = if (length > 1e-6f) this / length else ZERO

    companion object {
        val ZERO = Vec3(0f, 0f, 0f)
    }
}
