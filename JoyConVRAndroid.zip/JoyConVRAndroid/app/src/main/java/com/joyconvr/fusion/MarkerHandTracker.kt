package com.joyconvr.fusion

import com.google.ar.core.AugmentedImage
import com.google.ar.core.Frame
import com.google.ar.core.Pose
import com.google.ar.core.TrackingState
import com.joyconvr.joycon.JoyConDevice
import com.joyconvr.math.Quat
import com.joyconvr.math.Vec3

/**
 * Real tracking: ARCore Augmented Images, called directly against the ARCore Android SDK
 * (com.google.ar.core.Session/Frame) instead of going through AR Foundation's Unity layer.
 *
 * Requires: a Session configured with an AugmentedImageDatabase containing the left/right
 * marker images at their real physical size in meters (critical for accurate pose) — build
 * it in MainActivity from the images described in the assets markers folder (see the .md
 * print instructions there).
 *
 * Print requirements for the markers — see the .md files under assets/markers. Without a
 * printed and attached marker this component honestly tracks nothing — that's correct
 * behavior, ARCore doesn't recognize "just a Joy-Con" without a trained/registered image.
 */
class MarkerHandTracker(
    private val leftMarkerImageName: String = "joycon_left_marker",
    private val rightMarkerImageName: String = "joycon_right_marker",
    orientationAlpha: Float = 0.92f
) {
    val leftFilter = ComplementaryFilter().apply { this.orientationAlpha = orientationAlpha }
    val rightFilter = ComplementaryFilter().apply { this.orientationAlpha = orientationAlpha }

    /** Call once per rendered frame after session.update(), with the frame and current time (seconds). */
    fun onFrameUpdated(frame: Frame, nowSeconds: Float) {
        val updated = frame.getUpdatedTrackables(AugmentedImage::class.java)
        for (image in updated) {
            handleImage(image, nowSeconds)
        }
    }

    private fun handleImage(image: AugmentedImage, nowSeconds: Float) {
        if (image.trackingState != TrackingState.TRACKING) return

        val pose = image.centerPose
        when (image.name) {
            leftMarkerImageName -> leftFilter.correctWithMarker(pose.toVec3(), pose.toQuat(), nowSeconds)
            rightMarkerImageName -> rightFilter.correctWithMarker(pose.toVec3(), pose.toQuat(), nowSeconds)
        }
        // Images that drop out of `updated` simply stop arriving here; the filter keeps living
        // on pure gyro until hasMarkerRecently() expires (see VRHandController).
    }

    /** Called once per frame from VRHandController with the raw gyro sample (deg/s). */
    fun tickGyro(side: JoyConDevice.Side, gyroDegPerSec: Vec3, dt: Float) {
        val filter = if (side == JoyConDevice.Side.LEFT) leftFilter else rightFilter
        filter.integrateGyro(gyroDegPerSec, dt)
    }

    private fun Pose.toVec3() = Vec3(tx(), ty(), tz())
    private fun Pose.toQuat() = Quat(qx(), qy(), qz(), qw())
}
