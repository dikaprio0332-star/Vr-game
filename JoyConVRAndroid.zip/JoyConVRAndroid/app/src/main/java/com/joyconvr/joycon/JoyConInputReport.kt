package com.joyconvr.joycon

import com.joyconvr.math.Vec3

/**
 * One parsed input report 0x30 (standard full mode, 60Hz, with IMU).
 * Format per dekuNukem/Nintendo_Switch_Reverse_Engineering:
 *  byte0        report id (0x30)
 *  byte1        timer
 *  byte2        battery + connection info
 *  byte3-5      buttons (right, shared, left) — 3 bitmask bytes
 *  byte6-8      left stick (12-bit X, 12-bit Y packed into 3 bytes)
 *  byte9-11     right stick (12-bit X, 12-bit Y packed into 3 bytes)
 *  byte12       vibrator input report
 *  byte13-48    3 IMU samples of 12 bytes each: accelX,Y,Z (int16 LE) + gyroX,Y,Z (int16 LE),
 *               taken ~5ms apart — 3 samples per input report.
 */
class JoyConInputReport(
    val side: JoyConDevice.Side,
    val timerMs: Int,
    val batteryPercent: Int,
    val buttons: ButtonState,
    val stickX: Float,
    val stickY: Float,
    val imuSamples: Array<ImuSample>
) {
    data class ImuSample(
        val accelX: Float, val accelY: Float, val accelZ: Float, // in g
        val gyroX: Float, val gyroY: Float, val gyroZ: Float     // in deg/s
    ) {
        val accelG: Vec3 get() = Vec3(accelX, accelY, accelZ)
        val gyroDegPerS: Vec3 get() = Vec3(gyroX, gyroY, gyroZ)
    }

    data class ButtonState(
        val a: Boolean, val b: Boolean, val x: Boolean, val y: Boolean,
        val l: Boolean, val r: Boolean, val zl: Boolean, val zr: Boolean,
        val minus: Boolean, val plus: Boolean, val stickButton: Boolean,
        val home: Boolean, val capture: Boolean, val sr: Boolean, val sl: Boolean
    )

    companion object {
        // Default sensitivity for standard mode (no user calibration applied yet):
        // accel: 1G ~= 4096 LSB (range +-8G); gyro: 1 deg/s ~= 14.247 LSB (range +-2000dps)
        private const val ACCEL_LSB_PER_G = 4096f
        private const val GYRO_LSB_PER_DPS = 14.247f

        fun parse(buffer: ByteArray, length: Int, side: JoyConDevice.Side): JoyConInputReport? {
            if (length < 49) return null

            val timer = buffer[1].toInt() and 0xFF
            val battery = ((buffer[2].toInt() and 0xF0) shr 4) * 25 // 0-8 range -> rough %

            val btByte3 = buffer[3].toInt() and 0xFF // right-side buttons
            val btByte4 = buffer[4].toInt() and 0xFF // shared buttons
            val btByte5 = buffer[5].toInt() and 0xFF // left-side buttons (+ SL/SR for single JoyCon)

            val buttons = ButtonState(
                a = btByte3 and 0x08 != 0,
                b = btByte3 and 0x04 != 0,
                x = btByte3 and 0x02 != 0,
                y = btByte3 and 0x01 != 0,
                r = btByte3 and 0x40 != 0,
                zr = btByte3 and 0x80 != 0,
                l = btByte5 and 0x40 != 0,
                zl = btByte5 and 0x80 != 0,
                sr = btByte5 and 0x10 != 0,
                sl = btByte5 and 0x20 != 0,
                minus = btByte4 and 0x01 != 0,
                plus = btByte4 and 0x02 != 0,
                stickButton = (btByte4 and 0x04 != 0) || (btByte4 and 0x08 != 0),
                home = btByte4 and 0x10 != 0,
                capture = btByte4 and 0x20 != 0
            )

            val stickBytes = if (side == JoyConDevice.Side.LEFT)
                intArrayOf(buffer[6].toInt() and 0xFF, buffer[7].toInt() and 0xFF, buffer[8].toInt() and 0xFF)
            else
                intArrayOf(buffer[9].toInt() and 0xFF, buffer[10].toInt() and 0xFF, buffer[11].toInt() and 0xFF)

            val rawX = stickBytes[0] or ((stickBytes[1] and 0x0F) shl 8)
            val rawY = (stickBytes[1] shr 4) or (stickBytes[2] shl 4)
            // Stick center ~2048, range ~+-1100..1300 in raw 12-bit units.
            // Precise stick calibration lives in SPI 0x603D/0x6046; this is a rough normalization.
            val stickX = ((rawX - 2048) / 1200f).coerceIn(-1f, 1f)
            val stickY = ((rawY - 2048) / 1200f).coerceIn(-1f, 1f)

            val samples = Array(3) { i ->
                val off = 13 + i * 12
                val ax = int16LE(buffer, off) / ACCEL_LSB_PER_G
                val ay = int16LE(buffer, off + 2) / ACCEL_LSB_PER_G
                val az = int16LE(buffer, off + 4) / ACCEL_LSB_PER_G
                val gx = int16LE(buffer, off + 6) / GYRO_LSB_PER_DPS
                val gy = int16LE(buffer, off + 8) / GYRO_LSB_PER_DPS
                val gz = int16LE(buffer, off + 10) / GYRO_LSB_PER_DPS
                ImuSample(ax, ay, az, gx, gy, gz)
            }

            return JoyConInputReport(side, timer, battery, buttons, stickX, stickY, samples)
        }

        private fun int16LE(buffer: ByteArray, offset: Int): Int {
            val lo = buffer[offset].toInt() and 0xFF
            val hi = buffer[offset + 1].toInt()
            return (hi shl 8) or lo
        }
    }
}
