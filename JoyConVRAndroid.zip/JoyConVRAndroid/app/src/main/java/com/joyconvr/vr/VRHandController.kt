package com.joyconvr.vr

import com.joyconvr.fusion.MarkerHandTracker
import com.joyconvr.joycon.JoyConDevice
import com.joyconvr.joycon.JoyConInputReport
import com.joyconvr.joycon.JoyConManager
import com.joyconvr.math.Quat
import com.joyconvr.math.Vec3

/**
 * One hand (LEFT or RIGHT). Ported from VRHandController.cs: feeds raw gyro into the
 * marker tracker's fusion filter on every input report, and each render frame reads back the
 * filter's pose for the hand to use — unless the marker has been out of view too long, in
 * which case the hand intentionally freezes at its last known pose instead of drifting off on
 * pure gyro (no position sensor = it would eventually fly away).
 *
 * No stationary-calibration step: gyro samples are fed to the fusion filter as-is. The marker
 * tracker re-anchors position/orientation from the printed AR marker whenever it's in view, so
 * any small uncorrected gyro bias only affects the brief windows where the marker is out of
 * frame, rather than accumulating unchecked.
 */
class VRHandController(
    private val side: JoyConDevice.Side,
    private val markerTracker: MarkerHandTracker,
    private val markerTimeoutSeconds: Float = 1.5f
) : JoyConManager.Listener {

    var gripPressed: Boolean = false; private set
    var triggerPressed: Boolean = false; private set
    var stick: Vec3 = Vec3.ZERO; private set // z unused, kept as Vec3 for consistency

    var position: Vec3 = Vec3.ZERO; private set
    var rotation: Quat = Quat.IDENTITY; private set
    private var isConnected = false

    override fun onConnected(s: JoyConDevice.Side) { if (s == side) isConnected = true }
    override fun onDisconnected(s: JoyConDevice.Side, reason: String) { if (s == side) isConnected = false }

    override fun onInputReport(report: JoyConInputReport) {
        if (report.side != side) return

        stick = Vec3(report.stickX, report.stickY, 0f)
        gripPressed = if (side == JoyConDevice.Side.LEFT) report.buttons.l else report.buttons.r
        triggerPressed = if (side == JoyConDevice.Side.LEFT) report.buttons.zl else report.buttons.zr

        // Each report packs 3 IMU samples with their own honest dt (~5.5ms each, matching the
        // real Joy-Con protocol) — integrate all three, not just the last one.
        val sampleDt = 1f / 180f // 3 samples per 60Hz report ~= 180Hz effective
        for (raw in report.imuSamples) {
            markerTracker.tickGyro(side, raw.gyroDegPerS, sampleDt)
        }
    }

    /** Call once per render frame (after markerTracker.onFrameUpdated) with the current time in seconds. */
    fun updatePose(nowSeconds: Float) {
        if (!isConnected) return

        val filter = if (side == JoyConDevice.Side.LEFT) markerTracker.leftFilter else markerTracker.rightFilter
        if (!filter.initialized) return // wait for the marker's first appearance in frame

        if (filter.hasMarkerRecently(nowSeconds, markerTimeoutSeconds)) {
            position = filter.position
            rotation = filter.rotation
        }
        // If the marker hasn't been seen for a while, we deliberately stop updating — see
        // class doc above.
    }
}
