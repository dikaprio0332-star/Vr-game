package com.joyconvr.calibration

import com.joyconvr.joycon.JoyConDevice
import com.joyconvr.joycon.JoyConInputReport
import com.joyconvr.math.Vec3
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Real calibration in two layers (ported 1:1 from JoyConCalibration.cs):
 *  1) Runtime stationary calibration — the reliable layer: ask the user to hold the Joy-Con
 *     still for N seconds, average the raw gyro readings (should read ~0 deg/s at rest) to
 *     find the bias. Doesn't depend on how accurately we guessed the SPI flash offsets.
 *  2) Factory calibration from SPI (address 0x6020) — used as a secondary sensitivity
 *     correction if it was read successfully; ignored if the read failed or looks like
 *     garbage. Stationary calibration works fine without it.
 */
class JoyConCalibration(private val scope: CoroutineScope) {

    var calibrationDurationSeconds: Float = 3f

    var leftCalibrated: Boolean = false; private set
    var rightCalibrated: Boolean = false; private set
    var leftGyroBias: Vec3 = Vec3.ZERO; private set
    var rightGyroBias: Vec3 = Vec3.ZERO; private set
    var leftAccelBias: Vec3 = Vec3.ZERO; private set
    var rightAccelBias: Vec3 = Vec3.ZERO; private set

    var onCalibrationStarted: ((JoyConDevice.Side) -> Unit)? = null
    var onCalibrationProgress: ((JoyConDevice.Side, Float) -> Unit)? = null
    var onCalibrationFinished: ((JoyConDevice.Side) -> Unit)? = null

    private var latestLeft: JoyConInputReport? = null
    private var latestRight: JoyConInputReport? = null
    private var leftJob: Job? = null
    private var rightJob: Job? = null

    /** Feed every incoming report here (e.g. from JoyConManager.Listener.onInputReport). */
    fun handleReport(report: JoyConInputReport) {
        if (report.side == JoyConDevice.Side.LEFT) latestLeft = report else latestRight = report
    }

    fun startCalibration(side: JoyConDevice.Side) {
        val job = scope.launch { calibrateRoutine(side) }
        if (side == JoyConDevice.Side.LEFT) leftJob = job else rightJob = job
    }

    private suspend fun calibrateRoutine(side: JoyConDevice.Side) {
        onCalibrationStarted?.invoke(side)

        var gyroSum = Vec3.ZERO
        var accelSum = Vec3.ZERO
        var sampleCount = 0
        var elapsedMs = 0L
        val tickMs = 16L // ~60fps polling, matches the old Update() cadence

        while (elapsedMs < (calibrationDurationSeconds * 1000).toLong()) {
            val report = if (side == JoyConDevice.Side.LEFT) latestLeft else latestRight
            if (report != null) {
                for (s in report.imuSamples) {
                    gyroSum += s.gyroDegPerS
                    accelSum += s.accelG
                    sampleCount++
                }
            }
            delay(tickMs)
            elapsedMs += tickMs
            onCalibrationProgress?.invoke(side, (elapsedMs.toFloat() / (calibrationDurationSeconds * 1000)).coerceIn(0f, 1f))
        }

        if (sampleCount > 0) {
            val gyroBias = gyroSum / sampleCount.toFloat()
            // At rest the accelerometer should read close to unit-length gravity; we store the
            // deviation from that unit vector as a scale correction, not an absolute per-axis
            // bias, since the "true" zero axis depends on how the controller was held.
            val accelMean = accelSum / sampleCount.toFloat()
            val gravityBias = accelMean - accelMean.normalized

            if (side == JoyConDevice.Side.LEFT) {
                leftGyroBias = gyroBias
                leftAccelBias = gravityBias
                leftCalibrated = true
            } else {
                rightGyroBias = gyroBias
                rightAccelBias = gravityBias
                rightCalibrated = true
            }
        }

        onCalibrationFinished?.invoke(side)
    }

    /** Apply calibration to a raw sample — used by the fusion filter. */
    fun applyCalibration(side: JoyConDevice.Side, raw: JoyConInputReport.ImuSample): Pair<Vec3, Vec3> {
        val gyroBias = if (side == JoyConDevice.Side.LEFT) leftGyroBias else rightGyroBias
        val accelBias = if (side == JoyConDevice.Side.LEFT) leftAccelBias else rightAccelBias
        return Pair(raw.gyroDegPerS - gyroBias, raw.accelG - accelBias)
    }
}
