package com.joyconvr

import android.graphics.BitmapFactory
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.ar.core.AugmentedImageDatabase
import com.google.ar.core.Config
import com.google.ar.core.Session
import com.joyconvr.fusion.MarkerHandTracker
import com.joyconvr.joycon.JoyConDevice
import com.joyconvr.joycon.JoyConManager
import com.joyconvr.ui3d.BrowserPanel
import com.joyconvr.vr.StereoRenderer
import com.joyconvr.vr.VRHandController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class MainActivity : AppCompatActivity() {

    private val activityScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private lateinit var joyConManager: JoyConManager
    private lateinit var markerTracker: MarkerHandTracker
    private lateinit var leftHand: VRHandController
    private lateinit var rightHand: VRHandController
    private lateinit var glSurfaceView: GLSurfaceView
    private lateinit var browserPanel: BrowserPanel
    private var arSession: Session? = null
    private var plusWasDown = false

    companion object {
        private const val PERMISSION_REQUEST_CODE = 100
        private const val MARKER_WIDTH_METERS = 0.05f // print size — must match the physical printout, see assets/markers/*.md
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        glSurfaceView = findViewById(R.id.glSurfaceView)
        browserPanel = BrowserPanel(this, findViewById(R.id.rootContainer))

        joyConManager = JoyConManager(this)
        markerTracker = MarkerHandTracker(orientationAlpha = 0.92f)
        leftHand = VRHandController(JoyConDevice.Side.LEFT, markerTracker)
        rightHand = VRHandController(JoyConDevice.Side.RIGHT, markerTracker)

        joyConManager.addListener(leftHand)
        joyConManager.addListener(rightHand)
        joyConManager.addListener(object : JoyConManager.Listener {
            override fun onInputReport(report: com.joyconvr.joycon.JoyConInputReport) {
                // '+' toggles the floating browser panel open/closed (rising edge only).
                if (report.buttons.plus && !plusWasDown) {
                    browserPanel.toggle()
                }
                plusWasDown = report.buttons.plus
            }
            override fun onError(message: String) {
                Toast.makeText(this@MainActivity, "Joy-Con: $message", Toast.LENGTH_SHORT).show()
            }
        })

        if (joyConManager.allPermissionsGranted()) {
            initArAndConnect()
        } else {
            joyConManager.requestPermissions(PERMISSION_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE && joyConManager.allPermissionsGranted()) {
            initArAndConnect()
        }
    }

    private fun initArAndConnect() {
        val session = Session(this)
        val config = Config(session)
        config.focusMode = Config.FocusMode.AUTO

        // Marker images must be supplied as real bitmaps — assets/markers/*.md only contains
        // print instructions (same as the original Unity project's StreamingAssets). Add the
        // actual left_marker.png / right_marker.png you printed under app/src/main/assets/markers/
        // before this will find anything; without them ARCore has nothing registered to track,
        // same honest constraint as the original README described.
        try {
            val db = AugmentedImageDatabase(session)
            assets.open("markers/left_marker.png").use {
                db.addImage("joycon_left_marker", BitmapFactory.decodeStream(it), MARKER_WIDTH_METERS)
            }
            assets.open("markers/right_marker.png").use {
                db.addImage("joycon_right_marker", BitmapFactory.decodeStream(it), MARKER_WIDTH_METERS)
            }
            config.augmentedImageDatabase = db
        } catch (e: Exception) {
            Toast.makeText(this, "Marker images missing in assets/markers/ — printed markers won't track yet.", Toast.LENGTH_LONG).show()
        }

        session.configure(config)
        arSession = session

        glSurfaceView.setEGLContextClientVersion(2)
        glSurfaceView.setRenderer(StereoRenderer(this, session, leftHand, rightHand, markerTracker, browserPanel))
        glSurfaceView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        // Auto-connect to any already-bonded Joy-Cons found in system Bluetooth settings.
        val bonded = org.json.JSONArray(joyConManager.listBondedJoyCons())
        for (i in 0 until bonded.length()) {
            val o = bonded.getJSONObject(i)
            val side = if (o.getString("side") == "LEFT") JoyConDevice.Side.LEFT else JoyConDevice.Side.RIGHT
            joyConManager.connect(o.getString("address"), side)
        }
    }

    override fun onResume() {
        super.onResume()
        arSession?.resume()
        glSurfaceView.onResume()
    }

    override fun onPause() {
        super.onPause()
        glSurfaceView.onPause()
        arSession?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        joyConManager.disconnect(JoyConDevice.Side.LEFT)
        joyConManager.disconnect(JoyConDevice.Side.RIGHT)
        arSession?.close()
    }
}
