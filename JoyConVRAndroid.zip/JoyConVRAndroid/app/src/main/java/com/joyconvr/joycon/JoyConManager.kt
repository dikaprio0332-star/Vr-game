package com.joyconvr.joycon

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * Replaces the old two-hop path (JoyConUnityBridge.kt -> UnitySendMessage -> JoyConManager.cs).
 * Everything now runs in one process, so callbacks are plain Kotlin lambdas/interfaces instead
 * of a JSON string bounced through UnitySendMessage. Same Bluetooth/L2CAP logic underneath
 * (JoyConDevice is unchanged) — only the "how results get back to app code" layer changed.
 */
class JoyConManager(private val activity: Activity) : JoyConDevice.Listener {

    interface Listener {
        fun onConnected(side: JoyConDevice.Side) {}
        fun onDisconnected(side: JoyConDevice.Side, reason: String) {}
        fun onInputReport(report: JoyConInputReport) {}
        fun onCalibrationRaw(side: JoyConDevice.Side, address: Int, data: ByteArray) {}
        fun onError(message: String) {}
    }

    private val listeners = mutableListOf<Listener>()
    fun addListener(l: Listener) = listeners.add(l)
    fun removeListener(l: Listener) = listeners.remove(l)

    private var left: JoyConDevice? = null
    private var right: JoyConDevice? = null

    var leftConnected: Boolean = false; private set
    var rightConnected: Boolean = false; private set

    // ---------------- Permissions ----------------

    fun requiredPermissions(): Array<String> {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            needed += Manifest.permission.CAMERA

        if (Build.VERSION.SDK_INT >= 31) {
            if (ContextCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                needed += Manifest.permission.BLUETOOTH_CONNECT
            if (ContextCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                needed += Manifest.permission.BLUETOOTH_SCAN
        } else {
            if (ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                needed += Manifest.permission.ACCESS_FINE_LOCATION
        }
        return needed.toTypedArray()
    }

    fun requestPermissions(requestCode: Int) {
        val needed = requiredPermissions()
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(activity, needed, requestCode)
        }
    }

    fun allPermissionsGranted(): Boolean = requiredPermissions().isEmpty()

    // ---------------- Public API ----------------

    /** JSON list of Joy-Cons already bonded in system Bluetooth settings. */
    fun listBondedJoyCons(): String {
        val manager = activity.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter = manager.adapter ?: return "[]"
        val bonded = adapter.bondedDevices ?: emptySet()
        val arr = JSONArray()
        for (d in bonded) {
            val name = d.name ?: continue
            if (name.contains("Joy-Con", ignoreCase = true)) {
                val o = JSONObject()
                o.put("address", d.address)
                o.put("name", name)
                o.put("side", if (name.contains("(L)")) "LEFT" else if (name.contains("(R)")) "RIGHT" else "UNKNOWN")
                arr.put(o)
            }
        }
        return arr.toString()
    }

    fun connect(address: String, side: JoyConDevice.Side) {
        val manager = activity.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = manager.adapter
        if (adapter == null) {
            listeners.forEach { it.onError("no_bluetooth_adapter") }
            return
        }
        val device: BluetoothDevice = adapter.getRemoteDevice(address)
        val jc = JoyConDevice(device, side, this)
        if (side == JoyConDevice.Side.LEFT) left = jc else right = jc
        jc.connect()
    }

    fun disconnect(side: JoyConDevice.Side) {
        if (side == JoyConDevice.Side.LEFT) { left?.disconnect("user_request"); left = null }
        else { right?.disconnect("user_request"); right = null }
    }

    fun sendRumble(side: JoyConDevice.Side, amplitude01: Float) {
        (if (side == JoyConDevice.Side.LEFT) left else right)?.sendRumble(amplitude01)
    }

    fun requestCalibrationRead(side: JoyConDevice.Side, address: Int, length: Int) {
        (if (side == JoyConDevice.Side.LEFT) left else right)?.requestSpiRead(address, length)
    }

    // ---------------- JoyConDevice.Listener: background BT thread -> listeners ----------------
    // These fire on a background thread (see JoyConDevice.connect/readLoop); hop to the main
    // thread before touching UI or ARCore Session state.

    override fun onConnected(side: JoyConDevice.Side) {
        if (side == JoyConDevice.Side.LEFT) leftConnected = true else rightConnected = true
        activity.runOnUiThread { listeners.forEach { it.onConnected(side) } }
    }

    override fun onDisconnected(side: JoyConDevice.Side, reason: String) {
        if (side == JoyConDevice.Side.LEFT) leftConnected = false else rightConnected = false
        activity.runOnUiThread { listeners.forEach { it.onDisconnected(side, reason) } }
    }

    override fun onInputReport(side: JoyConDevice.Side, report: JoyConInputReport) {
        // High frequency (60Hz) — dispatched as-is, no JSON round-trip needed anymore.
        activity.runOnUiThread { listeners.forEach { it.onInputReport(report) } }
    }

    override fun onCalibrationRaw(side: JoyConDevice.Side, address: Int, data: ByteArray) {
        activity.runOnUiThread { listeners.forEach { it.onCalibrationRaw(side, address, data) } }
    }

    override fun onError(side: JoyConDevice.Side, message: String) {
        activity.runOnUiThread { listeners.forEach { it.onError("${side.name}|$message") } }
    }
}
