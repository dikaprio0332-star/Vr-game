package com.joyconvr.vr

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLES11Ext
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.Build
import android.view.Surface
import android.view.WindowManager
import com.google.ar.core.Coordinates2d
import com.google.ar.core.Frame
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.joyconvr.math.Vec3
import com.joyconvr.ui3d.BrowserPanel
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

/**
 * MR (passthrough mixed reality) stereo renderer: draws the live ARCore camera image as the
 * background for BOTH eyes, then draws a small hand-skeleton marker at each connected hand's
 * tracked pose on top, offset by half the IPD per eye.
 *
 * Each eye viewport is a plain rectangle ("square") filling its half of the screen — there is
 * no lens barrel-distortion pre-warp applied here. That kind of pre-warp is only needed for
 * cheap VR headsets with lenses (e.g. Cardboard-style); a flat MR/passthrough view like this
 * one is meant to be looked at directly (or through a beam-splitter/no-lens MR viewer), so a
 * flat rectangle per eye is correct and intentional.
 */
class StereoRenderer(
    private val context: Context,
    private val session: Session,
    private val leftHand: VRHandController,
    private val rightHand: VRHandController,
    private val markerTracker: com.joyconvr.fusion.MarkerHandTracker,
    private val browserPanel: BrowserPanel? = null
) : GLSurfaceView.Renderer {

    var interpupillaryDistanceMeters = 0.063f

    /**
     * Extra rotation (degrees) applied to the passthrough camera image on top of ARCore's own
     * display-rotation correction below. The phone sits tilted in this headset's mount rather
     * than flat, so ARCore's normal 0/90/180/270 correction alone still leaves the image
     * rotated — this manual offset compensates for that physical mounting angle. Tune this if
     * 45 isn't quite right for your particular mount.
     */
    var imageRotationDegrees: Float
        get() = cameraBackground.rotationDegrees
        set(value) { cameraBackground.rotationDegrees = value }

    private var cameraBackground = CameraBackgroundRenderer(imageRotationDegrees = 45f)
    private var handSkeleton = HandSkeletonRenderer()
    private var uiPanel = UiPanelRenderer()
    private var viewportWidth = 0
    private var viewportHeight = 0

    // Real current device/display rotation (Surface.ROTATION_0/90/180/270), read from the
    // window manager instead of being hardcoded — a fixed 0 here made ARCore's own
    // display-geometry correction wrong on this landscape-locked device.
    private var displayRotation = Surface.ROTATION_0

    // World-anchored pose of the browser panel — captured once when it's opened, so it stays
    // fixed in the room (Vision-Pro-style window) instead of following the camera around.
    private var panelModelMatrix: FloatArray? = null
    private var leftTriggerWasDown = false
    private var rightTriggerWasDown = false

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        cameraBackground.createOnGlThread()
        handSkeleton.createOnGlThread()
        uiPanel.createOnGlThread()
        session.setCameraTextureName(cameraBackground.textureId)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportWidth = width
        viewportHeight = height
        displayRotation = currentDisplayRotation()
        session.setDisplayGeometry(displayRotation, width, height)
    }

    private fun currentDisplayRotation(): Int {
        return if (Build.VERSION.SDK_INT >= 30) {
            context.display?.rotation ?: Surface.ROTATION_0
        } else {
            @Suppress("DEPRECATION")
            (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
        }
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val frame = try { session.update() } catch (e: Exception) { return }
        val nowSeconds = frame.timestamp / 1_000_000_000f
        markerTracker.onFrameUpdated(frame, nowSeconds)
        leftHand.updatePose(nowSeconds)
        rightHand.updatePose(nowSeconds)

        browserPanel?.let { panel ->
            if (panel.isVisible) {
                if (panelModelMatrix == null) {
                    panelModelMatrix = buildPanelAnchor(frame.camera.pose, panel.aspectRatio)
                }
                panelModelMatrix?.let { model -> handlePanelInteraction(model, panel) }
            } else {
                panelModelMatrix = null
            }
        }

        val camera = frame.camera
        val projection = FloatArray(16)
        camera.getProjectionMatrix(projection, 0, 0.05f, 20f)
        val baseView = FloatArray(16)
        camera.getViewMatrix(baseView, 0)

        val eyeWidth = viewportWidth / 2
        // Left eye fills the left half of the screen, right eye fills the right half — two
        // flat rectangles side by side, filling the whole screen. No barrel distortion.
        drawEye(0, eyeWidth, viewportHeight, projection, baseView, -interpupillaryDistanceMeters / 2f, frame)
        drawEye(eyeWidth, eyeWidth, viewportHeight, projection, baseView, interpupillaryDistanceMeters / 2f, frame)
    }

    /** Places the panel 1m in front of wherever the camera was facing when it was opened. */
    private fun buildPanelAnchor(cameraPose: Pose, aspect: Float): FloatArray {
        val distanceMeters = 1.0f
        val panelWidthMeters = 0.6f
        val panelHeightMeters = panelWidthMeters / aspect
        val anchorPose = cameraPose.compose(Pose.makeTranslation(0f, 0f, -distanceMeters))
        val model = FloatArray(16)
        anchorPose.toMatrix(model, 0)
        Matrix.scaleM(model, 0, panelWidthMeters, panelHeightMeters, 1f)
        return model
    }

    /** Trigger = click: a rising edge on either hand's trigger, while that hand is "touching"
     *  the panel plane, taps through to the browser at that point. */
    private fun handlePanelInteraction(model: FloatArray, panel: BrowserPanel) {
        val leftDown = leftHand.triggerPressed
        val rightDown = rightHand.triggerPressed
        if (leftDown && !leftTriggerWasDown) tryTap(model, panel, leftHand.position)
        if (rightDown && !rightTriggerWasDown) tryTap(model, panel, rightHand.position)
        leftTriggerWasDown = leftDown
        rightTriggerWasDown = rightDown
    }

    private fun tryTap(model: FloatArray, panel: BrowserPanel, handPosition: Vec3) {
        val inverse = FloatArray(16)
        if (!Matrix.invertM(inverse, 0, model, 0)) return

        val worldPoint = floatArrayOf(handPosition.x, handPosition.y, handPosition.z, 1f)
        val localPoint = FloatArray(4)
        Matrix.multiplyMV(localPoint, 0, inverse, 0, worldPoint, 0)

        val localX = localPoint[0]
        val localY = localPoint[1]
        val localZ = localPoint[2]

        // Local X/Y in [-0.5, 0.5] means the hand is over the panel rectangle; local Z is the
        // real-world distance from the panel's plane along its normal (not rescaled).
        if (kotlin.math.abs(localZ) > 0.25f) return
        if (localX < -0.5f || localX > 0.5f || localY < -0.5f || localY > 0.5f) return

        val u = localX + 0.5f
        val v = 1f - (localY + 0.5f)
        panel.handleTap(u, v)
    }

    private fun drawEye(x: Int, width: Int, height: Int, projection: FloatArray, baseView: FloatArray, eyeOffsetX: Float, frame: Frame) {
        GLES20.glViewport(x, 0, width, height)

        // Passthrough camera image, full-bleed rectangle for this eye.
        cameraBackground.draw(frame)

        val view = baseView.copyOf()
        Matrix.translateM(view, 0, eyeOffsetX, 0f, 0f)

        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(true)
        handSkeleton.draw(projection, view, leftHand.position, leftHand.rotation, 0.9f, 0.3f, 0.3f)
        handSkeleton.draw(projection, view, rightHand.position, rightHand.rotation, 0.3f, 0.5f, 0.9f)

        val panel = browserPanel
        val model = panelModelMatrix
        if (panel != null && panel.isVisible && model != null) {
            val viewModel = FloatArray(16)
            Matrix.multiplyMM(viewModel, 0, view, 0, model, 0)
            val mvp = FloatArray(16)
            Matrix.multiplyMM(mvp, 0, projection, 0, viewModel, 0)
            uiPanel.draw(mvp, panel.snapshot(), panel.contentVersion)
        }
    }
}

/** Compiles a shader and returns its handle. Shared by the two small renderers below. */
internal fun loadShader(type: Int, source: String): Int {
    val shader = GLES20.glCreateShader(type)
    GLES20.glShaderSource(shader, source)
    GLES20.glCompileShader(shader)
    return shader
}

internal fun linkProgram(vertexSrc: String, fragmentSrc: String): Int {
    val vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexSrc)
    val fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentSrc)
    val program = GLES20.glCreateProgram()
    GLES20.glAttachShader(program, vertexShader)
    GLES20.glAttachShader(program, fragmentShader)
    GLES20.glLinkProgram(program)
    return program
}

internal fun directFloatBuffer(data: FloatArray): FloatBuffer =
    ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(data)
        position(0)
    }

/**
 * Fullscreen (per-eye-viewport) textured quad showing the ARCore camera passthrough image —
 * this is the actual "MR" part of the app (real camera image, not a black/empty background).
 */
private class CameraBackgroundRenderer(imageRotationDegrees: Float = 0f) {
    var textureId = -1
        private set

    /** Extra manual rotation (degrees) applied to the sampled image, see StereoRenderer docs. */
    var rotationDegrees: Float = imageRotationDegrees

    private var program = 0
    private var positionAttrib = 0
    private var texCoordAttrib = 0
    private var textureUniform = 0

    // Full-screen quad in normalized device coordinates (two triangles as a strip).
    private val quadCoords = directFloatBuffer(floatArrayOf(-1f, -1f, +1f, -1f, -1f, +1f, +1f, +1f))
    private val quadTexCoords = directFloatBuffer(floatArrayOf(0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f))
    private val transformedTexCoords = directFloatBuffer(FloatArray(8))
    private val baseTexCoords = FloatArray(8)
    private val rotatedTexCoords = directFloatBuffer(FloatArray(8))

    /** Rotates UV points about the texture center (0.5, 0.5) by [rotationDegrees]. */
    private fun applyManualRotation() {
        if (rotationDegrees == 0f) {
            rotatedTexCoords.position(0)
            rotatedTexCoords.put(baseTexCoords)
            rotatedTexCoords.position(0)
            return
        }
        val rad = Math.toRadians(rotationDegrees.toDouble())
        val cosA = cos(rad).toFloat()
        val sinA = sin(rad).toFloat()
        val out = FloatArray(8)
        var i = 0
        while (i < 8) {
            val u = baseTexCoords[i] - 0.5f
            val v = baseTexCoords[i + 1] - 0.5f
            out[i] = (u * cosA - v * sinA) + 0.5f
            out[i + 1] = (u * sinA + v * cosA) + 0.5f
            i += 2
        }
        rotatedTexCoords.position(0)
        rotatedTexCoords.put(out)
        rotatedTexCoords.position(0)
    }

    fun createOnGlThread() {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        textureId = textures[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        program = linkProgram(
            """
            attribute vec4 a_Position;
            attribute vec2 a_TexCoord;
            varying vec2 v_TexCoord;
            void main() {
                gl_Position = a_Position;
                v_TexCoord = a_TexCoord;
            }
            """.trimIndent(),
            """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 v_TexCoord;
            uniform samplerExternalOES u_Texture;
            void main() {
                gl_FragColor = texture2D(u_Texture, v_TexCoord);
            }
            """.trimIndent()
        )
        positionAttrib = GLES20.glGetAttribLocation(program, "a_Position")
        texCoordAttrib = GLES20.glGetAttribLocation(program, "a_TexCoord")
        textureUniform = GLES20.glGetUniformLocation(program, "u_Texture")
    }

    /** Draws the current camera frame as a flat rectangle filling the active viewport. */
    fun draw(frame: Frame) {
        if (frame.hasDisplayGeometryChanged()) {
            frame.transformCoordinates2d(
                Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,
                quadCoords,
                Coordinates2d.TEXTURE_NORMALIZED,
                transformedTexCoords
            )
            transformedTexCoords.position(0)
            transformedTexCoords.get(baseTexCoords)
            transformedTexCoords.position(0)
        }
        // Re-applied every frame (cheap: 4 points) so tweaking rotationDegrees at runtime
        // takes effect immediately without waiting for the next display-geometry change.
        applyManualRotation()

        // Passthrough background: no depth test/write, always drawn first.
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(false)

        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glUniform1i(textureUniform, 0)

        quadCoords.position(0)
        GLES20.glVertexAttribPointer(positionAttrib, 2, GLES20.GL_FLOAT, false, 0, quadCoords)
        rotatedTexCoords.position(0)
        GLES20.glVertexAttribPointer(texCoordAttrib, 2, GLES20.GL_FLOAT, false, 0, rotatedTexCoords)

        GLES20.glEnableVertexAttribArray(positionAttrib)
        GLES20.glEnableVertexAttribArray(texCoordAttrib)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(positionAttrib)
        GLES20.glDisableVertexAttribArray(texCoordAttrib)
    }
}


