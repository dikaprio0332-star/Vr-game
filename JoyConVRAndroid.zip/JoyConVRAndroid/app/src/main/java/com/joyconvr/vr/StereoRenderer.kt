package com.joyconvr.vr

import android.opengl.GLES20
import android.opengl.GLES11Ext
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.google.ar.core.Coordinates2d
import com.google.ar.core.Frame
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.joyconvr.math.Vec3
import com.joyconvr.ui3d.BrowserPanel
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * MR (passthrough mixed reality) stereo renderer: draws the live ARCore camera image as the
 * background for BOTH eyes, then draws a small marker cube at each connected hand's tracked
 * pose on top, offset by half the IPD per eye.
 *
 * Each eye viewport is a plain rectangle ("square") filling its half of the screen — there is
 * no lens barrel-distortion pre-warp applied here. That kind of pre-warp is only needed for
 * cheap VR headsets with lenses (e.g. Cardboard-style); a flat MR/passthrough view like this
 * one is meant to be looked at directly (or through a beam-splitter/no-lens MR viewer), so a
 * flat rectangle per eye is correct and intentional.
 */
class StereoRenderer(
    private val session: Session,
    private val leftHand: VRHandController,
    private val rightHand: VRHandController,
    private val markerTracker: com.joyconvr.fusion.MarkerHandTracker,
    private val browserPanel: BrowserPanel? = null
) : GLSurfaceView.Renderer {

    var interpupillaryDistanceMeters = 0.063f

    private var cameraBackground = CameraBackgroundRenderer()
    private var handCube = HandCubeRenderer()
    private var uiPanel = UiPanelRenderer()
    private var viewportWidth = 0
    private var viewportHeight = 0
    private var displayRotation = 0

    // World-anchored pose of the browser panel — captured once when it's opened, so it stays
    // fixed in the room (Vision-Pro-style window) instead of following the camera around.
    private var panelModelMatrix: FloatArray? = null
    private var leftTriggerWasDown = false
    private var rightTriggerWasDown = false

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        cameraBackground.createOnGlThread()
        handCube.createOnGlThread()
        uiPanel.createOnGlThread()
        session.setCameraTextureName(cameraBackground.textureId)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportWidth = width
        viewportHeight = height
        session.setDisplayGeometry(displayRotation, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val frame = try { session.update() } catch (e: Exception) { return }
        val nowSeconds = frame.timestamp / 1_000_000_000f
        markerTracker.onFrameUpdated(frame, nowSeconds)
        leftHand.updatePose(nowSeconds)
        rightHand.updatePose(nowSeconds)

        browserPanel?.let { panel ->
            if (panel.isVisible) {
                if (panelModelMatrix == null) {
                    panelModelMatrix = buildPanelAnchor(frame.camera.pose, panel.aspectRatio)
                }
                panelModelMatrix?.let { model -> handlePanelInteraction(model, panel) }
            } else {
                panelModelMatrix = null
            }
        }

        val camera = frame.camera
        val projection = FloatArray(16)
        camera.getProjectionMatrix(projection, 0, 0.05f, 20f)
        val baseView = FloatArray(16)
        camera.getViewMatrix(baseView, 0)

        val eyeWidth = viewportWidth / 2
        // Left eye fills the left half of the screen, right eye fills the right half — two
        // flat rectangles side by side, filling the whole screen. No barrel distortion.
        drawEye(0, eyeWidth, viewportHeight, projection, baseView, -interpupillaryDistanceMeters / 2f, frame)
        drawEye(eyeWidth, eyeWidth, viewportHeight, projection, baseView, interpupillaryDistanceMeters / 2f, frame)
    }

    /** Places the panel 1m in front of wherever the camera was facing when it was opened. */
    private fun buildPanelAnchor(cameraPose: Pose, aspect: Float): FloatArray {
        val distanceMeters = 1.0f
        val panelWidthMeters = 0.6f
        val panelHeightMeters = panelWidthMeters / aspect
        val anchorPose = cameraPose.compose(Pose.makeTranslation(0f, 0f, -distanceMeters))
        val model = FloatArray(16)
        anchorPose.toMatrix(model, 0)
        Matrix.scaleM(model, 0, panelWidthMeters, panelHeightMeters, 1f)
        return model
    }

    /** Trigger = click: a rising edge on either hand's trigger, while that hand is "touching"
     *  the panel plane, taps through to the browser at that point. */
    private fun handlePanelInteraction(model: FloatArray, panel: BrowserPanel) {
        val leftDown = leftHand.triggerPressed
        val rightDown = rightHand.triggerPressed
        if (leftDown && !leftTriggerWasDown) tryTap(model, panel, leftHand.position)
        if (rightDown && !rightTriggerWasDown) tryTap(model, panel, rightHand.position)
        leftTriggerWasDown = leftDown
        rightTriggerWasDown = rightDown
    }

    private fun tryTap(model: FloatArray, panel: BrowserPanel, handPosition: Vec3) {
        val inverse = FloatArray(16)
        if (!Matrix.invertM(inverse, 0, model, 0)) return

        val worldPoint = floatArrayOf(handPosition.x, handPosition.y, handPosition.z, 1f)
        val localPoint = FloatArray(4)
        Matrix.multiplyMV(localPoint, 0, inverse, 0, worldPoint, 0)

        val localX = localPoint[0]
        val localY = localPoint[1]
        val localZ = localPoint[2]

        // Local X/Y in [-0.5, 0.5] means the hand is over the panel rectangle; local Z is the
        // real-world distance from the panel's plane along its normal (not rescaled).
        if (kotlin.math.abs(localZ) > 0.25f) return
        if (localX < -0.5f || localX > 0.5f || localY < -0.5f || localY > 0.5f) return

        val u = localX + 0.5f
        val v = 1f - (localY + 0.5f)
        panel.handleTap(u, v)
    }

    private fun drawEye(x: Int, width: Int, height: Int, projection: FloatArray, baseView: FloatArray, eyeOffsetX: Float, frame: Frame) {
        GLES20.glViewport(x, 0, width, height)

        // Passthrough camera image, full-bleed rectangle for this eye.
        cameraBackground.draw(frame)

        val view = baseView.copyOf()
        Matrix.translateM(view, 0, eyeOffsetX, 0f, 0f)

        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(true)
        handCube.draw(projection, view, leftHand.position, 0.02f, 0.9f, 0.3f, 0.3f)
        handCube.draw(projection, view, rightHand.position, 0.02f, 0.3f, 0.5f, 0.9f)

        val panel = browserPanel
        val model = panelModelMatrix
        if (panel != null && panel.isVisible && model != null) {
            val viewModel = FloatArray(16)
            Matrix.multiplyMM(viewModel, 0, view, 0, model, 0)
            val mvp = FloatArray(16)
            Matrix.multiplyMM(mvp, 0, projection, 0, viewModel, 0)
            uiPanel.draw(mvp, panel.snapshot(), panel.contentVersion)
        }
    }
}

/** Compiles a shader and returns its handle. Shared by the two small renderers below. */
internal fun loadShader(type: Int, source: String): Int {
    val shader = GLES20.glCreateShader(type)
    GLES20.glShaderSource(shader, source)
    GLES20.glCompileShader(shader)
    return shader
}

internal fun linkProgram(vertexSrc: String, fragmentSrc: String): Int {
    val vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexSrc)
    val fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentSrc)
    val program = GLES20.glCreateProgram()
    GLES20.glAttachShader(program, vertexShader)
    GLES20.glAttachShader(program, fragmentShader)
    GLES20.glLinkProgram(program)
    return program
}

internal fun directFloatBuffer(data: FloatArray): FloatBuffer =
    ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(data)
        position(0)
    }

/**
 * Fullscreen (per-eye-viewport) textured quad showing the ARCore camera passthrough image —
 * this is the actual "MR" part of the app (real camera image, not a black/empty background).
 */
private class CameraBackgroundRenderer {
    var textureId = -1
        private set

    private var program = 0
    private var positionAttrib = 0
    private var texCoordAttrib = 0
    private var textureUniform = 0

    // Full-screen quad in normalized device coordinates (two triangles as a strip).
    private val quadCoords = directFloatBuffer(floatArrayOf(-1f, -1f, +1f, -1f, -1f, +1f, +1f, +1f))
    private val quadTexCoords = directFloatBuffer(floatArrayOf(0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f))
    private val transformedTexCoords = directFloatBuffer(FloatArray(8))

    fun createOnGlThread() {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        textureId = textures[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        program = linkProgram(
            """
            attribute vec4 a_Position;
            attribute vec2 a_TexCoord;
            varying vec2 v_TexCoord;
            void main() {
                gl_Position = a_Position;
                v_TexCoord = a_TexCoord;
            }
            """.trimIndent(),
            """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 v_TexCoord;
            uniform samplerExternalOES u_Texture;
            void main() {
                gl_FragColor = texture2D(u_Texture, v_TexCoord);
            }
            """.trimIndent()
        )
        positionAttrib = GLES20.glGetAttribLocation(program, "a_Position")
        texCoordAttrib = GLES20.glGetAttribLocation(program, "a_TexCoord")
        textureUniform = GLES20.glGetUniformLocation(program, "u_Texture")
    }

    /** Draws the current camera frame as a flat rectangle filling the active viewport. */
    fun draw(frame: Frame) {
        if (frame.hasDisplayGeometryChanged()) {
            frame.transformCoordinates2d(
                Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,
                quadCoords,
                Coordinates2d.TEXTURE_NORMALIZED,
                transformedTexCoords
            )
        }

        // Passthrough background: no depth test/write, always drawn first.
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(false)

        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glUniform1i(textureUniform, 0)

        quadCoords.position(0)
        GLES20.glVertexAttribPointer(positionAttrib, 2, GLES20.GL_FLOAT, false, 0, quadCoords)
        transformedTexCoords.position(0)
        GLES20.glVertexAttribPointer(texCoordAttrib, 2, GLES20.GL_FLOAT, false, 0, transformedTexCoords)

        GLES20.glEnableVertexAttribArray(positionAttrib)
        GLES20.glEnableVertexAttribArray(texCoordAttrib)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(positionAttrib)
        GLES20.glDisableVertexAttribArray(texCoordAttrib)
    }
}

/** Small solid-color cube used as a placeholder hand marker at a tracked pose. */
private class HandCubeRenderer {
    private var program = 0
    private var positionAttrib = 0
    private var mvpUniform = 0
    private var colorUniform = 0
    private val vertexBuffer = directFloatBuffer(cubeVertices(0.5f))

    fun createOnGlThread() {
        program = linkProgram(
            """
            uniform mat4 u_MVP;
            attribute vec4 a_Position;
            void main() {
                gl_Position = u_MVP * a_Position;
            }
            """.trimIndent(),
            """
            precision mediump float;
            uniform vec4 u_Color;
            void main() {
                gl_FragColor = u_Color;
            }
            """.trimIndent()
        )
        positionAttrib = GLES20.glGetAttribLocation(program, "a_Position")
        mvpUniform = GLES20.glGetUniformLocation(program, "u_MVP")
        colorUniform = GLES20.glGetUniformLocation(program, "u_Color")
    }

    fun draw(projection: FloatArray, view: FloatArray, position: Vec3, size: Float, r: Float, g: Float, b: Float) {
        val model = FloatArray(16)
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, position.x, position.y, position.z)
        Matrix.scaleM(model, 0, size, size, size)

        val viewModel = FloatArray(16)
        Matrix.multiplyMM(viewModel, 0, view, 0, model, 0)
        val mvp = FloatArray(16)
        Matrix.multiplyMM(mvp, 0, projection, 0, viewModel, 0)

        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(mvpUniform, 1, false, mvp, 0)
        GLES20.glUniform4f(colorUniform, r, g, b, 1f)

        vertexBuffer.position(0)
        GLES20.glVertexAttribPointer(positionAttrib, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer)
        GLES20.glEnableVertexAttribArray(positionAttrib)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
        GLES20.glDisableVertexAttribArray(positionAttrib)
    }

    private companion object {
        fun cubeVertices(s: Float): FloatArray = floatArrayOf(
            // front
            -s, -s, s, s, -s, s, s, s, s, -s, -s, s, s, s, s, -s, s, s,
            // back
            -s, -s, -s, -s, s, -s, s, s, -s, -s, -s, -s, s, s, -s, s, -s, -s,
            // left
            -s, -s, -s, -s, -s, s, -s, s, s, -s, -s, -s, -s, s, s, -s, s, -s,
            // right
            s, -s, -s, s, s, -s, s, s, s, s, -s, -s, s, s, s, s, -s, s,
            // top
            -s, s, -s, -s, s, s, s, s, s, -s, s, -s, s, s, s, s, s, -s,
            // bottom
            -s, -s, -s, s, -s, -s, s, -s, s, -s, -s, -s, s, -s, s, -s, -s, s
        )
    }
}
