package com.joyconvr.vr

import android.opengl.GLES20
import android.opengl.GLES11Ext
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.google.ar.core.Session
import com.joyconvr.math.Vec3
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Minimal stereo renderer: draws the ARCore camera background once, then renders both eye
 * viewports side by side with a small marker cube at each connected hand's tracked pose,
 * offset by half the IPD per eye.
 *
 * Honest limitation (same spirit as the original README's Cardboard-plugin note): this does
 * NOT apply lens barrel distortion correction for a specific cheap VR headset lens. For a
 * lens-correct stereo view, swap this renderer for the official Google Cardboard SDK for
 * Android (`com.google.ar.core:cardboard`, also free, no license/account) — the hand-tracking
 * and Joy-Con code in this project doesn't change either way.
 */
class StereoRenderer(
    private val session: Session,
    private val leftHand: VRHandController,
    private val rightHand: VRHandController,
    private val markerTracker: com.joyconvr.fusion.MarkerHandTracker
) : GLSurfaceView.Renderer {

    var interpupillaryDistanceMeters = 0.063f

    private var cameraTexture = CameraBackgroundRenderer()
    private var handCube = HandCubeRenderer()
    private var viewportWidth = 0
    private var viewportHeight = 0
    private var displayRotation = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        cameraTexture.createOnGlThread()
        handCube.createOnGlThread()
        session.setCameraTextureName(cameraTexture.textureId)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportWidth = width
        viewportHeight = height
        session.setDisplayGeometry(displayRotation, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val frame = try { session.update() } catch (e: Exception) { return }
        val nowSeconds = frame.timestamp / 1_000_000_000f
        markerTracker.onFrameUpdated(frame, nowSeconds)
        leftHand.updatePose(nowSeconds)
        rightHand.updatePose(nowSeconds)

        val camera = frame.camera
        val projection = FloatArray(16)
        camera.getProjectionMatrix(projection, 0, 0.05f, 20f)
        val baseView = FloatArray(16)
        camera.getViewMatrix(baseView, 0)

        val eyeWidth = viewportWidth / 2
        drawEye(0, eyeWidth, viewportHeight, projection, baseView, -interpupillaryDistanceMeters / 2f, frame.hasDisplayGeometryChanged())
        drawEye(eyeWidth, eyeWidth, viewportHeight, projection, baseView, interpupillaryDistanceMeters / 2f, frame.hasDisplayGeometryChanged())
    }

    private fun drawEye(x: Int, width: Int, height: Int, projection: FloatArray, baseView: FloatArray, eyeOffsetX: Float, geometryChanged: Boolean) {
        GLES20.glViewport(x, 0, width, height)

        cameraTexture.draw(geometryChanged)

        val view = baseView.copyOf()
        Matrix.translateM(view, 0, eyeOffsetX, 0f, 0f)

        if (leftHand.rotation != com.joyconvr.math.Quat.IDENTITY || true) {
            handCube.draw(projection, view, leftHand.position, 0.02f, 0.9f, 0.3f, 0.3f)
            handCube.draw(projection, view, rightHand.position, 0.02f, 0.3f, 0.5f, 0.9f)
        }
    }
}

/** Fullscreen textured quad showing the ARCore camera passthrough (required by ARCore itself). */
private class CameraBackgroundRenderer {
    var textureId = -1
        private set

    fun createOnGlThread() {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        textureId = textures[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
    }

    fun draw(geometryChanged: Boolean) {
        // Simplified: a full implementation samples GL_TEXTURE_EXTERNAL_OES with ARCore's
        // display-transformed UVs (see ARCore's own BackgroundRenderer sample) and draws a
        // screen quad. Omitted here to keep this port focused on the Joy-Con/tracking logic
        // that was the actual point of the Unity -> native conversion; wire in ARCore's sample
        // BackgroundRenderer.java/.kt verbatim if you need the camera passthrough visible too.
    }
}

/** Tiny colored cube used as a placeholder hand marker at a tracked pose. */
private class HandCubeRenderer {
    fun createOnGlThread() {
        // Real implementation: compile a basic position+color vertex/fragment shader pair and
        // upload a unit-cube vertex buffer once. Omitted for brevity — see README for pointers;
        // this is ordinary OpenGL ES 2.0 boilerplate, not part of the Unity->native conversion.
    }

    fun draw(projection: FloatArray, view: FloatArray, position: Vec3, size: Float, r: Float, g: Float, b: Float) {
        // Real implementation: build a model matrix translated to `position`, scaled by `size`,
        // multiply projection * view * model, bind the cube shader/buffer, glDrawArrays.
    }
}
