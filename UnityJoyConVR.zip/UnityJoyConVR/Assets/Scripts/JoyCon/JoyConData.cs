using System;
using UnityEngine;

namespace JoyConVR
{
    public enum JoyConSide { LEFT, RIGHT }

    [Serializable]
    public struct ImuSample
    {
        public Vector3 accelG;      // ускорение в единицах g, в системе координат Joy-Con
        public Vector3 gyroDegPerS; // угловая скорость, градусы/сек
    }

    [Serializable]
    public struct JoyConButtons
    {
        public bool a, b, x, y;
        public bool l, r, zl, zr;
        public bool minus, plus, stickButton, home, capture, sr, sl;
    }

    [Serializable]
    public class JoyConInputReport
    {
        public JoyConSide side;
        public int timerMs;
        public int battery;
        public float stickX;
        public float stickY;
        public JoyConButtons buttons;
        public ImuSample[] imu; // обычно 3 сэмпла за один report (сняты каждые ~5мс)
    }

    /// <summary>Разбор JSON, который шлёт Kotlin-плагин (org.json на стороне Android).</summary>
    internal static class JoyConReportParser
    {
        public static JoyConInputReport Parse(string json)
        {
            // Простой ручной парсер вместо JsonUtility, т.к. JsonUtility плохо работает
            // с вложенными массивами объектов переменной длины без обёрточного класса.
            var root = MiniJson.Parse(json) as System.Collections.Generic.Dictionary<string, object>;
            if (root == null) return null;

            var report = new JoyConInputReport
            {
                side = ((string)root["side"] == "LEFT") ? JoyConSide.LEFT : JoyConSide.RIGHT,
                timerMs = Convert.ToInt32(root["timerMs"]),
                battery = Convert.ToInt32(root["battery"]),
                stickX = Convert.ToSingle(root["stickX"]),
                stickY = Convert.ToSingle(root["stickY"])
            };

            var b = root["buttons"] as System.Collections.Generic.Dictionary<string, object>;
            report.buttons = new JoyConButtons
            {
                a = (bool)b["a"], b = (bool)b["b"], x = (bool)b["x"], y = (bool)b["y"],
                l = (bool)b["l"], r = (bool)b["r"], zl = (bool)b["zl"], zr = (bool)b["zr"],
                minus = (bool)b["minus"], plus = (bool)b["plus"],
                stickButton = (bool)b["stick"], home = (bool)b["home"],
                capture = (bool)b["capture"], sr = (bool)b["sr"], sl = (bool)b["sl"]
            };

            var imuArr = root["imu"] as System.Collections.Generic.List<object>;
            report.imu = new ImuSample[imuArr.Count];
            for (int i = 0; i < imuArr.Count; i++)
            {
                var s = imuArr[i] as System.Collections.Generic.Dictionary<string, object>;
                report.imu[i] = new ImuSample
                {
                    accelG = new Vector3(Convert.ToSingle(s["ax"]), Convert.ToSingle(s["ay"]), Convert.ToSingle(s["az"])),
                    gyroDegPerS = new Vector3(Convert.ToSingle(s["gx"]), Convert.ToSingle(s["gy"]), Convert.ToSingle(s["gz"]))
                };
            }
            return report;
        }
    }
}
