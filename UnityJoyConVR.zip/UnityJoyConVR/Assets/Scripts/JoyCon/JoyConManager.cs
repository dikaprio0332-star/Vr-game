using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Android;

namespace JoyConVR
{
    /// <summary>
    /// ВАЖНО: GameObject с этим компонентом должен называться ровно "JoyConManager" —
    /// именно на это имя нативный плагин шлёт UnitySendMessage(...). Переименуете —
    /// сломаете связь с Android-стороной.
    /// </summary>
    public class JoyConManager : MonoBehaviour
    {
        public static JoyConManager Instance { get; private set; }

        public event Action<JoyConSide> OnConnected;
        public event Action<JoyConSide, string> OnDisconnected;
        public event Action<JoyConInputReport> OnInputReport;
        public event Action<JoyConSide, int, byte[]> OnCalibrationRaw;
        public event Action<string> OnError;

        [Header("Статус (только для отладки в инспекторе)")]
        [SerializeField] private bool leftConnected;
        [SerializeField] private bool rightConnected;

#if UNITY_ANDROID && !UNITY_EDITOR
        private AndroidJavaObject bridge;
        private AndroidJavaObject currentActivity;
#endif

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            name = "JoyConManager"; // подстраховка на случай, если объект переименовали в сцене
        }

        private void Start()
        {
            RequestPermissionsThenInit();
        }

        // ---------------- Разрешения ----------------

        public void RequestPermissionsThenInit()
        {
            var needed = new List<string>();

#if UNITY_ANDROID
            if (!Permission.HasUserAuthorizedPermission(Permission.Camera))
                needed.Add(Permission.Camera);

            // На Android 12+ имена разрешений другие — Unity Permission API их знает по строке
            const string btConnect = "android.permission.BLUETOOTH_CONNECT";
            const string btScan = "android.permission.BLUETOOTH_SCAN";
            if (AndroidApiLevel() >= 31)
            {
                if (!Permission.HasUserAuthorizedPermission(btConnect)) needed.Add(btConnect);
                if (!Permission.HasUserAuthorizedPermission(btScan)) needed.Add(btScan);
            }
            else
            {
                const string fineLocation = "android.permission.ACCESS_FINE_LOCATION";
                if (!Permission.HasUserAuthorizedPermission(fineLocation)) needed.Add(fineLocation);
            }
#endif

            if (needed.Count > 0)
            {
                var callbacks = new PermissionCallbacks();
                callbacks.PermissionGranted += _ => TryInitBridgeIfAllGranted(needed);
                callbacks.PermissionDenied += p => OnError?.Invoke($"permission_denied:{p}");
                callbacks.PermissionDeniedAndDontAskAgain += p => OnError?.Invoke($"permission_denied_permanent:{p}");
                Permission.RequestUserPermissions(needed.ToArray(), callbacks);
            }
            else
            {
                InitBridge();
            }
        }

        private readonly HashSet<string> grantedThisRun = new HashSet<string>();
        private void TryInitBridgeIfAllGranted(List<string> needed)
        {
            // Упрощённо: как только что-то выдано — перепроверяем все нужные разрешения целиком
            bool allGranted = true;
            foreach (var p in needed)
                if (!Permission.HasUserAuthorizedPermission(p)) { allGranted = false; break; }
            if (allGranted) InitBridge();
        }

        private int AndroidApiLevel()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            using var version = new AndroidJavaClass("android.os.Build$VERSION");
            return version.GetStatic<int>("SDK_INT");
#else
            return 0;
#endif
        }

        // ---------------- Инициализация нативного моста ----------------

        private void InitBridge()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            using var unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            currentActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
            bridge = new AndroidJavaObject("com.joyconvr.plugin.JoyConUnityBridge");
            Debug.Log("[JoyConManager] Native bridge initialized.");
#else
            Debug.LogWarning("[JoyConManager] Нативный BT-мост доступен только на устройстве Android, не в редакторе.");
#endif
        }

        // ---------------- Публичное API для UI/логики ----------------

        /// <summary>JSON-список уже сопряжённых в системных настройках Joy-Con.</summary>
        public string ListBondedJoyCons()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            using var context = currentActivity.Call<AndroidJavaObject>("getApplicationContext");
            using var kotlinObject = new AndroidJavaClass("com.joyconvr.plugin.JoyConUnityBridge");
            using var instance = kotlinObject.GetStatic<AndroidJavaObject>("INSTANCE");
            return instance.Call<string>("listBondedJoyCons", context);
#else
            return "[]";
#endif
        }

        public void Connect(string address, JoyConSide side)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            using var context = currentActivity.Call<AndroidJavaObject>("getApplicationContext");
            using var kotlinObject = new AndroidJavaClass("com.joyconvr.plugin.JoyConUnityBridge");
            var instance = kotlinObject.GetStatic<AndroidJavaObject>("INSTANCE");
            instance.Call("connect", context, address, side.ToString());
#else
            Debug.LogWarning($"[JoyConManager] Connect({address}, {side}) — доступно только на устройстве.");
#endif
        }

        public void Disconnect(JoyConSide side)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            var kotlinObject = new AndroidJavaClass("com.joyconvr.plugin.JoyConUnityBridge");
            var instance = kotlinObject.GetStatic<AndroidJavaObject>("INSTANCE");
            instance.Call("disconnect", side.ToString());
#endif
        }

        public void RequestCalibrationRead(JoyConSide side, int address, int length)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            var kotlinObject = new AndroidJavaClass("com.joyconvr.plugin.JoyConUnityBridge");
            var instance = kotlinObject.GetStatic<AndroidJavaObject>("INSTANCE");
            instance.Call("requestCalibrationRead", side.ToString(), address, length);
#endif
        }

        public void SendRumble(JoyConSide side, float amplitude01)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            var kotlinObject = new AndroidJavaClass("com.joyconvr.plugin.JoyConUnityBridge");
            var instance = kotlinObject.GetStatic<AndroidJavaObject>("INSTANCE");
            instance.Call("sendRumble", side.ToString(), amplitude01);
#endif
        }

        // ---------------- Коллбэки от UnitySendMessage (вызываются Android-стороной) ----------------
        // Имена методов ниже жёстко зашиты в JoyConUnityBridge.kt — не переименовывать без правки Kotlin.

        public void OnJoyConConnected(string sideStr)
        {
            var side = sideStr == "LEFT" ? JoyConSide.LEFT : JoyConSide.RIGHT;
            if (side == JoyConSide.LEFT) leftConnected = true; else rightConnected = true;
            OnConnected?.Invoke(side);
        }

        public void OnJoyConDisconnected(string payload)
        {
            var parts = payload.Split('|');
            var side = parts[0] == "LEFT" ? JoyConSide.LEFT : JoyConSide.RIGHT;
            if (side == JoyConSide.LEFT) leftConnected = false; else rightConnected = false;
            OnDisconnected?.Invoke(side, parts.Length > 1 ? parts[1] : "unknown");
        }

        public void OnJoyConInputReport(string json)
        {
            var report = JoyConReportParser.Parse(json);
            if (report != null) OnInputReport?.Invoke(report);
        }

        public void OnCalibrationRaw(string payload)
        {
            var parts = payload.Split('|');
            var side = parts[0] == "LEFT" ? JoyConSide.LEFT : JoyConSide.RIGHT;
            int address = int.Parse(parts[1]);
            byte[] data = HexToBytes(parts[2]);
            OnCalibrationRaw?.Invoke(side, address, data);
        }

        public void OnBridgeError(string message)
        {
            Debug.LogWarning($"[JoyConManager] Bridge error: {message}");
            OnError?.Invoke(message);
        }

        private static byte[] HexToBytes(string hex)
        {
            var bytes = new byte[hex.Length / 2];
            for (int i = 0; i < bytes.Length; i++)
                bytes[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
            return bytes;
        }
    }
}
