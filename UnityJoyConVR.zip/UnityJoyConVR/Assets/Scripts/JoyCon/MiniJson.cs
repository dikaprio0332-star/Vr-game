// MiniJSON — минималистичный JSON-парсер/сериализатор для C#.
// Основано на широко используемой public-domain реализации Calvin Rien
// (https://gist.github.com/darktable/1411710), которую массово используют
// в Unity-проектах именно потому, что встроенный JsonUtility не умеет
// разбирать произвольные Dictionary/List без заранее известной схемы —
// а нам нужно принимать JSON произвольной вложенности от Android-плагина.
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace JoyConVR
{
    public static class MiniJson
    {
        public static object Parse(string json)
        {
            if (json == null) return null;
            return Parser.Parse(json);
        }

        private sealed class Parser : IDisposable
        {
            private const string WHITE_SPACE = " \t\n\r";
            private const string WORD_BREAK = " \t\n\r{}[],:\"";
            private enum TOKEN { NONE, CURLY_OPEN, CURLY_CLOSE, SQUARED_OPEN, SQUARED_CLOSE, COLON, COMMA, STRING, NUMBER, TRUE, FALSE, NULL }

            private readonly System.IO.StringReader json;
            private Parser(string jsonString) { json = new System.IO.StringReader(jsonString); }

            public static object Parse(string jsonString)
            {
                using (var instance = new Parser(jsonString)) return instance.ParseValue();
            }

            public void Dispose() { json.Dispose(); }

            private Dictionary<string, object> ParseObject()
            {
                var table = new Dictionary<string, object>();
                json.Read(); // {
                while (true)
                {
                    switch (NextToken)
                    {
                        case TOKEN.NONE: return null;
                        case TOKEN.COMMA: continue;
                        case TOKEN.CURLY_CLOSE: return table;
                        default:
                            string name = ParseString();
                            if (name == null) return null;
                            if (NextToken != TOKEN.COLON) return null;
                            json.Read();
                            table[name] = ParseValue();
                            break;
                    }
                }
            }

            private List<object> ParseArray()
            {
                var array = new List<object>();
                json.Read(); // [
                var parsing = true;
                while (parsing)
                {
                    TOKEN nextToken = NextToken;
                    switch (nextToken)
                    {
                        case TOKEN.NONE: return null;
                        case TOKEN.COMMA: continue;
                        case TOKEN.SQUARED_CLOSE: parsing = false; break;
                        default: array.Add(ParseByToken(nextToken)); break;
                    }
                }
                return array;
            }

            private object ParseValue()
            {
                TOKEN nextToken = NextToken;
                return ParseByToken(nextToken);
            }

            private object ParseByToken(TOKEN token)
            {
                switch (token)
                {
                    case TOKEN.STRING: return ParseString();
                    case TOKEN.NUMBER: return ParseNumber();
                    case TOKEN.CURLY_OPEN: return ParseObject();
                    case TOKEN.SQUARED_OPEN: return ParseArray();
                    case TOKEN.TRUE: json.Read(); json.Read(); json.Read(); return true;
                    case TOKEN.FALSE: json.Read(); json.Read(); json.Read(); json.Read(); return false;
                    case TOKEN.NULL: json.Read(); json.Read(); json.Read(); json.Read(); return null;
                    default: return null;
                }
            }

            private string ParseString()
            {
                var s = new StringBuilder();
                json.Read(); // "
                while (true)
                {
                    if (json.Peek() == -1) break;
                    char c = NextChar;
                    if (c == '"') break;
                    if (c == '\\')
                    {
                        if (json.Peek() == -1) break;
                        c = NextChar;
                        switch (c)
                        {
                            case '"': case '\\': case '/': s.Append(c); break;
                            case 'b': s.Append('\b'); break;
                            case 'f': s.Append('\f'); break;
                            case 'n': s.Append('\n'); break;
                            case 'r': s.Append('\r'); break;
                            case 't': s.Append('\t'); break;
                            case 'u':
                                var hex = new char[4];
                                for (int i = 0; i < 4; i++) hex[i] = NextChar;
                                s.Append((char)Convert.ToInt32(new string(hex), 16));
                                break;
                        }
                    }
                    else s.Append(c);
                }
                return s.ToString();
            }

            private object ParseNumber()
            {
                string number = NextWord;
                if (number.IndexOf('.') == -1 && number.IndexOf('e') == -1 && number.IndexOf('E') == -1)
                {
                    long.TryParse(number, out long parsedInt);
                    return parsedInt;
                }
                double.TryParse(number, System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture, out double parsedDouble);
                return parsedDouble;
            }

            private void EatWhitespace()
            {
                while (WHITE_SPACE.IndexOf(PeekChar) != -1)
                {
                    json.Read();
                    if (json.Peek() == -1) break;
                }
            }

            private char PeekChar => Convert.ToChar(json.Peek());
            private char NextChar => Convert.ToChar(json.Read());

            private string NextWord
            {
                get
                {
                    var word = new StringBuilder();
                    while (WORD_BREAK.IndexOf(PeekChar) == -1)
                    {
                        word.Append(NextChar);
                        if (json.Peek() == -1) break;
                    }
                    return word.ToString();
                }
            }

            private TOKEN NextToken
            {
                get
                {
                    EatWhitespace();
                    if (json.Peek() == -1) return TOKEN.NONE;
                    switch (PeekChar)
                    {
                        case '{': return TOKEN.CURLY_OPEN;
                        case '}': json.Read(); return TOKEN.CURLY_CLOSE;
                        case '[': return TOKEN.SQUARED_OPEN;
                        case ']': json.Read(); return TOKEN.SQUARED_CLOSE;
                        case ',': json.Read(); return TOKEN.COMMA;
                        case '"': return TOKEN.STRING;
                        case ':': return TOKEN.COLON;
                    }
                    string word = NextWord;
                    switch (word)
                    {
                        case "false": return TOKEN.FALSE;
                        case "true": return TOKEN.TRUE;
                        case "null": return TOKEN.NULL;
                    }
                    if (word.IndexOf('-') != -1 || word.Length > 0 && char.IsDigit(word[0]))
                        return TOKEN.NUMBER;
                    return TOKEN.NONE;
                }
            }
        }
    }
}
