using UnityEngine;
using UnityEngine.UI;

namespace JoyConVR
{
    /// <summary>Подключить к сцене калибровки. Text/Slider ссылки — перетащить в инспекторе.</summary>
    public class CalibrationUI : MonoBehaviour
    {
        [SerializeField] private JoyConCalibration calibration;
        [SerializeField] private Text statusText;
        [SerializeField] private Slider progressLeft;
        [SerializeField] private Slider progressRight;
        [SerializeField] private Button startButton;

        private void OnEnable()
        {
            calibration.OnCalibrationStarted += side => SetStatus($"Держите {SideName(side)} Joy-Con неподвижно...");
            calibration.OnCalibrationProgress += HandleProgress;
            calibration.OnCalibrationFinished += side => SetStatus($"{SideName(side)} откалиброван.");
            startButton.onClick.AddListener(StartBoth);
        }

        private void OnDisable()
        {
            startButton.onClick.RemoveListener(StartBoth);
        }

        private void StartBoth()
        {
            calibration.StartCalibration(JoyConSide.LEFT);
            calibration.StartCalibration(JoyConSide.RIGHT);
        }

        private void HandleProgress(JoyConSide side, float t)
        {
            var slider = side == JoyConSide.LEFT ? progressLeft : progressRight;
            if (slider != null) slider.value = t;
        }

        private void SetStatus(string s)
        {
            if (statusText != null) statusText.text = s;
        }

        private static string SideName(JoyConSide s) => s == JoyConSide.LEFT ? "левый" : "правый";
    }
}
