using System.Collections;
using UnityEngine;

namespace JoyConVR
{
    /// <summary>
    /// Реальная калибровка в двух слоях:
    ///  1) Runtime stationary calibration — самый надёжный слой: просим держать
    ///     Joy-Con неподвижно N секунд, усредняем сырые показания гироскопа
    ///     (в покое должны быть ~0 deg/s) и находим bias. Не зависит от того,
    ///     насколько точно мы угадали офсеты SPI-флеша.
    ///  2) Заводская калибровка из SPI (адрес 0x6020) — используется как
    ///     дополнительная поправка чувствительности, если её удалось прочитать;
    ///     если чтение не удалось/данные выглядят мусором — просто игнорируется,
    ///     stationary-калибровка работает и без неё.
    /// </summary>
    public class JoyConCalibration : MonoBehaviour
    {
        [SerializeField] private float calibrationDurationSeconds = 3f;

        public bool LeftCalibrated { get; private set; }
        public bool RightCalibrated { get; private set; }

        public Vector3 LeftGyroBias { get; private set; }
        public Vector3 RightGyroBias { get; private set; }
        public Vector3 LeftAccelBias { get; private set; }
        public Vector3 RightAccelBias { get; private set; }

        public event System.Action<JoyConSide> OnCalibrationStarted;
        public event System.Action<JoyConSide, float> OnCalibrationProgress; // 0..1
        public event System.Action<JoyConSide> OnCalibrationFinished;

        private Coroutine leftRoutine, rightRoutine;

        private void OnEnable()
        {
            if (JoyConManager.Instance != null)
                JoyConManager.Instance.OnInputReport += HandleReportDuringCalibration;
        }

        private void OnDisable()
        {
            if (JoyConManager.Instance != null)
                JoyConManager.Instance.OnInputReport -= HandleReportDuringCalibration;
        }

        private JoyConInputReport latestLeft, latestRight;
        private void HandleReportDuringCalibration(JoyConInputReport r)
        {
            if (r.side == JoyConSide.LEFT) latestLeft = r; else latestRight = r;
        }

        public void StartCalibration(JoyConSide side)
        {
            var routine = StartCoroutine(CalibrateRoutine(side));
            if (side == JoyConSide.LEFT) leftRoutine = routine; else rightRoutine = routine;
        }

        private IEnumerator CalibrateRoutine(JoyConSide side)
        {
            OnCalibrationStarted?.Invoke(side);

            Vector3 gyroSum = Vector3.zero;
            Vector3 accelSum = Vector3.zero;
            int sampleCount = 0;
            float elapsed = 0f;

            while (elapsed < calibrationDurationSeconds)
            {
                var report = side == JoyConSide.LEFT ? latestLeft : latestRight;
                if (report != null)
                {
                    foreach (var s in report.imu)
                    {
                        gyroSum += s.gyroDegPerS;
                        accelSum += s.accelG;
                        sampleCount++;
                    }
                }
                elapsed += Time.deltaTime;
                OnCalibrationProgress?.Invoke(side, Mathf.Clamp01(elapsed / calibrationDurationSeconds));
                yield return null;
            }

            if (sampleCount > 0)
            {
                var gyroBias = gyroSum / sampleCount;
                // В покое акселерометр должен показывать (0,1,0) или (0,0,1) в зависимости от
                // ориентации осей контроллера — здесь мы храним отклонение от единичной длины
                // по фактически измеренному вектору гравитации, а не абсолютный bias по осям,
                // т.к. верная "нулевая" ось зависит от того, как контроллер держат при калибровке.
                var accelMean = accelSum / sampleCount;
                var gravityBias = accelMean - accelMean.normalized; // поправка на неточность масштаба

                if (side == JoyConSide.LEFT)
                {
                    LeftGyroBias = gyroBias;
                    LeftAccelBias = gravityBias;
                    LeftCalibrated = true;
                }
                else
                {
                    RightGyroBias = gyroBias;
                    RightAccelBias = gravityBias;
                    RightCalibrated = true;
                }
            }

            OnCalibrationFinished?.Invoke(side);
        }

        /// <summary>Применить калибровку к сырому сэмплу — используется фильтром слияния.</summary>
        public ImuSample ApplyCalibration(JoyConSide side, ImuSample raw)
        {
            var gyroBias = side == JoyConSide.LEFT ? LeftGyroBias : RightGyroBias;
            var accelBias = side == JoyConSide.LEFT ? LeftAccelBias : RightAccelBias;
            return new ImuSample
            {
                gyroDegPerS = raw.gyroDegPerS - gyroBias,
                accelG = raw.accelG - accelBias
            };
        }
    }
}
