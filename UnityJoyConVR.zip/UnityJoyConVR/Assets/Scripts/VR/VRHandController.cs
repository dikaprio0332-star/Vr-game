using UnityEngine;

namespace JoyConVR
{
    public class VRHandController : MonoBehaviour
    {
        [SerializeField] private JoyConSide side;
        [SerializeField] private MarkerHandTracker markerTracker;
        [SerializeField] private JoyConCalibration calibration;
        [SerializeField] private Animator handAnimator; // опционально: анимация сжатия кисти

        [Header("Если маркер не виден дольше этого — рука 'застывает', не улетает по дрейфу")]
        [SerializeField] private float markerTimeoutSeconds = 1.5f;

        private JoyConInputReport latestReport;
        private bool isConnected;

        public bool GripPressed { get; private set; }
        public bool TriggerPressed { get; private set; }
        public Vector2 Stick { get; private set; }

        private void OnEnable()
        {
            var mgr = JoyConManager.Instance;
            if (mgr == null) return;
            mgr.OnInputReport += HandleReport;
            mgr.OnConnected += s => { if (s == side) isConnected = true; };
            mgr.OnDisconnected += (s, _) => { if (s == side) isConnected = false; };
        }

        private void OnDisable()
        {
            var mgr = JoyConManager.Instance;
            if (mgr == null) return;
            mgr.OnInputReport -= HandleReport;
        }

        private void HandleReport(JoyConInputReport report)
        {
            if (report.side != side) return;
            latestReport = report;

            Stick = new Vector2(report.stickX, report.stickY);
            GripPressed = side == JoyConSide.LEFT ? report.buttons.l : report.buttons.r;
            TriggerPressed = side == JoyConSide.LEFT ? report.buttons.zl : report.buttons.zr;

            if (handAnimator != null)
                handAnimator.SetFloat("Grip", GripPressed ? 1f : 0f);

            // Гироскоп интегрируем сразу по приходу пакета (внутри одного report — 3 IMU-сэмпла,
            // каждый честно со своим dt ~5.5мс, как в реальном протоколе Joy-Con)
            const float sampleDt = 1f / 180f; // 3 сэмпла на 60Гц report ≈ 180Гц эффективно
            foreach (var raw in report.imu)
            {
                var calibrated = calibration != null ? calibration.ApplyCalibration(side, raw) : raw;
                markerTracker.TickGyro(side, calibrated.gyroDegPerS, sampleDt);
            }
        }

        private void Update()
        {
            if (!isConnected) return;

            var filter = side == JoyConSide.LEFT ? markerTracker.LeftFilter : markerTracker.RightFilter;
            if (!filter.Initialized) return; // ждём первого попадания маркера в кадр

            if (filter.HasMarkerRecently(Time.time, markerTimeoutSeconds))
            {
                transform.localPosition = filter.Position;
                transform.localRotation = filter.Rotation;
            }
            // если маркер долго не виден — намеренно не двигаем руку дальше по чистому
            // гироскопу (без позиции он всё равно "уплывёт" в пространстве), рука
            // просто останавливается на последней известной позиции до возврата маркера в кадр.
        }
    }
}
