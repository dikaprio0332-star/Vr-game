using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

namespace JoyConVR
{
    /// <summary>
    /// Реальный трекинг: ARCore Augmented Images через официальный пакет ARFoundation.
    /// Требует: AR Session + AR Session Origin с ARTrackedImageManager в сцене,
    /// заполненную XR Reference Image Library с картинками left/right маркеров и
    /// их реальным физическим размером в метрах (критично для точной позы).
    ///
    /// Печатные требования к маркерам — см. Assets/StreamingAssets/Markers/*.md.
    /// Без напечатанного и приклеенного маркера этот компонент честно ничего не
    /// затрекает — так и должно быть, ARCore не распознаёт "просто Joy-Con".
    /// </summary>
    [RequireComponent(typeof(ARTrackedImageManager))]
    public class MarkerHandTracker : MonoBehaviour
    {
        [Header("Имена референс-изображений в XR Reference Image Library")]
        [SerializeField] private string leftMarkerImageName = "joycon_left_marker";
        [SerializeField] private string rightMarkerImageName = "joycon_right_marker";

        [Header("Смешивание с гироскопом")]
        [SerializeField] private float orientationAlpha = 0.92f;

        public ComplementaryFilter LeftFilter { get; } = new ComplementaryFilter();
        public ComplementaryFilter RightFilter { get; } = new ComplementaryFilter();

        private ARTrackedImageManager trackedImageManager;

        private void Awake()
        {
            trackedImageManager = GetComponent<ARTrackedImageManager>();
            LeftFilter.OrientationAlpha = orientationAlpha;
            RightFilter.OrientationAlpha = orientationAlpha;
        }

        private void OnEnable() => trackedImageManager.trackedImagesChanged += OnTrackedImagesChanged;
        private void OnDisable() => trackedImageManager.trackedImagesChanged -= OnTrackedImagesChanged;

        private void OnTrackedImagesChanged(ARTrackedImagesChangedEventArgs args)
        {
            foreach (var image in args.added) HandleImage(image);
            foreach (var image in args.updated) HandleImage(image);
            // args.removed: трекинг маркера потерян — фильтр продолжит жить на чистом
            // гироскопе, пока HasMarkerRecently() не истечёт (см. VRHandController).
        }

        private void HandleImage(ARTrackedImage image)
        {
            if (image.trackingState != TrackingState.Tracking) return;

            var pose = image.transform;
            float now = Time.time;

            if (image.referenceImage.name == leftMarkerImageName)
                LeftFilter.CorrectWithMarker(pose.position, pose.rotation, now);
            else if (image.referenceImage.name == rightMarkerImageName)
                RightFilter.CorrectWithMarker(pose.position, pose.rotation, now);
        }

        /// <summary>Вызывается из VRHandController каждый кадр с калиброванным гироскопом.</summary>
        public void TickGyro(JoyConSide side, Vector3 calibratedGyroDegPerSec, float dt)
        {
            var filter = side == JoyConSide.LEFT ? LeftFilter : RightFilter;
            filter.IntegrateGyro(calibratedGyroDegPerSec, dt);
        }
    }
}
