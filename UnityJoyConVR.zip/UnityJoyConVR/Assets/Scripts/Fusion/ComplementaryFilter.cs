using UnityEngine;

namespace JoyConVR
{
    /// <summary>
    /// Честный комплементарный фильтр, а не имитация: гироскоп Joy-Con интегрируется
    /// каждый кадр (быстро, ~60-200Гц через BT, но дрейфует по ориентации и вообще
    /// не даёт позицию), маркер камеры даёт редкие (частота кадров ARCore, обычно
    /// 30-60Гц, но с задержкой обработки и потерями при перекрытии) абсолютные
    /// поза-коррекции. Итог: ориентация = смесь гироскопа и маркера по весу alpha,
    /// позиция = поза маркера (по камере она абсолютная — гироскоп/акселерометр
    /// позицию не измеряют, двойное интегрирование акселерометра для позиции
    /// физически ненадёжно на таких MEMS-датчиках и здесь намеренно не используется,
    /// чтобы не выдавать дрейфующий шум за "реальную" позицию).
    /// </summary>
    public class ComplementaryFilter
    {
        /// <summary>
        /// Вес доверия гироскопу при каждой коррекции маркером. Ближе к 1 — более
        /// плавно, но сильнее накопленный дрейф между кадрами маркера. Ближе к 0 —
        /// резче "прилипает" к маркеру, меньше дрейфа, но заметнее джиттер камеры.
        /// </summary>
        public float OrientationAlpha = 0.92f;

        private Quaternion fusedOrientation = Quaternion.identity;
        private Vector3 fusedPosition = Vector3.zero;
        private bool initialized;
        private float lastMarkerTimestamp = -1f;

        /// <summary>Вызывать каждый кадр с калиброванным гироскопом (град/сек) и dt.</summary>
        public void IntegrateGyro(Vector3 gyroDegPerSecond, float dt)
        {
            if (!initialized) return;
            // Joy-Con IMU оси: X вдоль контроллера, Y вбок, Z вверх (зависит от ориентации
            // держания — см. README по калибровке осей перед использованием в конкретной сцене).
            var delta = Quaternion.Euler(gyroDegPerSecond * dt);
            fusedOrientation = fusedOrientation * delta;
        }

        /// <summary>Вызывать при каждом новом валидном трекинге маркера (ARTrackedImage).</summary>
        public void CorrectWithMarker(Vector3 markerPosition, Quaternion markerRotation, float timestamp)
        {
            if (!initialized)
            {
                fusedPosition = markerPosition;
                fusedOrientation = markerRotation;
                initialized = true;
                lastMarkerTimestamp = timestamp;
                return;
            }

            // Позиция целиком берётся из маркера — честно, без придуманной "виртуальной" точности.
            fusedPosition = markerPosition;

            // Ориентация — комплементарная смесь: между обновлениями маркера мы уже
            // "уехали" за счёт гироскопа, поэтому не жёстко перезаписываем, а слерпим.
            fusedOrientation = Quaternion.Slerp(markerRotation, fusedOrientation, OrientationAlpha);

            lastMarkerTimestamp = timestamp;
        }

        public bool HasMarkerRecently(float now, float maxAgeSeconds = 1.5f) =>
            lastMarkerTimestamp >= 0 && (now - lastMarkerTimestamp) <= maxAgeSeconds;

        public Vector3 Position => fusedPosition;
        public Quaternion Rotation => fusedOrientation;
        public bool Initialized => initialized;

        public void Reset()
        {
            initialized = false;
            fusedOrientation = Quaternion.identity;
            fusedPosition = Vector3.zero;
            lastMarkerTimestamp = -1f;
        }
    }
}
