using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace JoyConVR.EditorTools
{
    /// <summary>
    /// JoyConUnityBridge.kt (Assets/Plugins/Android/JoyConPlugin) references
    /// com.unity3d.player.UnityPlayer and is compiled against classes.jar
    /// ("compileOnly files('libs/classes.jar')" in that module's build.gradle).
    /// That jar is not something you check into source control - it ships
    /// inside the Unity Editor install. This step copies it into
    /// Assets/Plugins/Android/JoyConPlugin/libs/ right before the Android
    /// build so the Gradle module can compile, whether you're building
    /// locally or in CI (game-ci/unity-builder).
    /// </summary>
    public class PreBuildCopyUnityClassesJar : IPreprocessBuildWithReport
    {
        public int callbackOrder => 0;

        public void OnPreprocessBuild(BuildReport report)
        {
            if (report.summary.platform != BuildTarget.Android) return;

            string contents = EditorApplication.applicationContentsPath;

            string[] candidates =
            {
                Path.Combine(contents, "PlaybackEngines", "AndroidPlayer", "Variations", "il2cpp", "Release", "Classes", "classes.jar"),
                Path.Combine(contents, "PlaybackEngines", "AndroidPlayer", "Variations", "mono", "Release", "Classes", "classes.jar"),
                Path.Combine(contents, "PlaybackEngines", "AndroidPlayer", "Development", "Classes", "classes.jar"),
                Path.Combine(contents, "PlaybackEngines", "AndroidPlayer", "Release", "Classes", "classes.jar"),
            };

            string source = null;
            foreach (var candidate in candidates)
            {
                if (File.Exists(candidate))
                {
                    source = candidate;
                    break;
                }
            }

            string destDir = Path.Combine(Application.dataPath, "Plugins", "Android", "JoyConPlugin", "libs");
            string dest = Path.Combine(destDir, "classes.jar");

            if (source == null)
            {
                throw new BuildFailedException(
                    "PreBuildCopyUnityClassesJar: couldn't find classes.jar under the Android " +
                    "PlaybackEngines folder of this Unity install (looked in: " +
                    string.Join(", ", candidates) +
                    "). The JoyConPlugin Android Library module needs it to compile against " +
                    "UnityPlayer. If your Unity install lays it out differently, update the " +
                    "candidate paths in this script or place classes.jar manually at " + dest);
            }

            Directory.CreateDirectory(destDir);
            File.Copy(source, dest, overwrite: true);
            Debug.Log($"[PreBuildCopyUnityClassesJar] Copied {source} -> {dest}");
        }
    }
}
