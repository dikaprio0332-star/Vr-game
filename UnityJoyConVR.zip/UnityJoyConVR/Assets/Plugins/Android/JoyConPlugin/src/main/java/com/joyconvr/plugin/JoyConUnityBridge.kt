package com.joyconvr.plugin

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.os.Build
import com.unity3d.player.UnityPlayer

/**
 * Единственная точка входа, которую вызывает C# (через AndroidJavaObject).
 * Все методы можно дергать из Unity-скрипта JoyConManager.cs.
 *
 * Unity получает данные обратно через UnitySendMessage(gameObjectName, methodName, jsonString) —
 * это стандартный, официальный механизм связи Android-плагина с Unity, не заглушка.
 */
object JoyConUnityBridge : JoyConDevice.Listener {

    private const val UNITY_GAME_OBJECT = "JoyConManager" // имя GameObject-получателя в сцене

    private var left: JoyConDevice? = null
    private var right: JoyConDevice? = null

    fun hasBluetoothPermissions(activity: Activity): Boolean {
        if (Build.VERSION.SDK_INT >= 31) {
            val connect = activity.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT)
            val scan = activity.checkSelfPermission(android.Manifest.permission.BLUETOOTH_SCAN)
            return connect == android.content.pm.PackageManager.PERMISSION_GRANTED &&
                    scan == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        return true // на старых версиях достаточно manifest-разрешений
    }

    fun requestBluetoothPermissions(activity: Activity, requestCode: Int) {
        if (Build.VERSION.SDK_INT >= 31) {
            activity.requestPermissions(
                arrayOf(
                    android.Manifest.permission.BLUETOOTH_CONNECT,
                    android.Manifest.permission.BLUETOOTH_SCAN
                ),
                requestCode
            )
        }
    }

    /** Возвращает JSON-массив уже сопряжённых (Settings > Bluetooth) устройств с именем Joy-Con. */
    fun listBondedJoyCons(context: Context): String {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter = manager.adapter ?: return "[]"
        val bonded = adapter.bondedDevices ?: emptySet()
        val arr = org.json.JSONArray()
        for (d in bonded) {
            val name = d.name ?: continue
            if (name.contains("Joy-Con", ignoreCase = true)) {
                val o = org.json.JSONObject()
                o.put("address", d.address)
                o.put("name", name)
                o.put("side", if (name.contains("(L)")) "LEFT" else if (name.contains("(R)")) "RIGHT" else "UNKNOWN")
                arr.put(o)
            }
        }
        return arr.toString()
    }

    fun connect(context: Context, address: String, sideStr: String) {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = manager.adapter ?: run {
            UnityPlayer.UnitySendMessage(UNITY_GAME_OBJECT, "OnBridgeError", "no_bluetooth_adapter")
            return
        }
        val device: BluetoothDevice = adapter.getRemoteDevice(address)
        val side = if (sideStr == "LEFT") JoyConDevice.Side.LEFT else JoyConDevice.Side.RIGHT
        val jc = JoyConDevice(device, side, this)
        if (side == JoyConDevice.Side.LEFT) left = jc else right = jc
        jc.connect()
    }

    fun disconnect(sideStr: String) {
        if (sideStr == "LEFT") { left?.disconnect("user_request"); left = null }
        else { right?.disconnect("user_request"); right = null }
    }

    fun setPlayerLights(sideStr: String, mask: Int) {
        (if (sideStr == "LEFT") left else right)?.setPlayerLights(mask)
    }

    fun sendRumble(sideStr: String, amplitude: Float) {
        (if (sideStr == "LEFT") left else right)?.sendRumble(amplitude)
    }

    fun requestCalibrationRead(sideStr: String, address: Int, length: Int) {
        (if (sideStr == "LEFT") left else right)?.requestSpiRead(address, length)
    }

    // ---- JoyConDevice.Listener: коллбэки из фонового BT-потока -> в Unity ----

    override fun onConnected(side: JoyConDevice.Side) {
        UnityPlayer.UnitySendMessage(UNITY_GAME_OBJECT, "OnJoyConConnected", side.name)
    }

    override fun onDisconnected(side: JoyConDevice.Side, reason: String) {
        UnityPlayer.UnitySendMessage(UNITY_GAME_OBJECT, "OnJoyConDisconnected", "${side.name}|$reason")
    }

    override fun onInputReport(side: JoyConDevice.Side, report: JoyConInputReport) {
        // Высокая частота (60Гц) — шлём компактный JSON, Unity сам решает, что с этим делать
        UnityPlayer.UnitySendMessage(UNITY_GAME_OBJECT, "OnJoyConInputReport", report.toJson())
    }

    override fun onCalibrationRaw(side: JoyConDevice.Side, address: Int, data: ByteArray) {
        val hex = data.joinToString("") { "%02x".format(it) }
        UnityPlayer.UnitySendMessage(
            UNITY_GAME_OBJECT, "OnCalibrationRaw",
            "${side.name}|${address}|${hex}"
        )
    }

    override fun onError(side: JoyConDevice.Side, message: String) {
        UnityPlayer.UnitySendMessage(UNITY_GAME_OBJECT, "OnBridgeError", "${side.name}|$message")
    }
}
