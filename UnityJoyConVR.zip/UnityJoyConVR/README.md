# Joy-Con VR для Android (Unity)

Скелет реального проекта: 2 Joy-Con по Bluetooth (L2CAP, без root), калибровка,
трекинг рук маркерами через ARCore (ARFoundation Image Tracking), слияние
камера+гироскоп комплементарным фильтром, VR-руки, стерео-рендер через
Google Cardboard XR Plugin.

## Что тут реальное, а не заглушка

- **Bluetooth**: нативный Android-плагин (Kotlin) подключается к Joy-Con через
  `BluetoothDevice.createInsecureL2capChannel(psm)` (API 29+) на PSM `0x11`
  (control) и `0x13` (interrupt) — это официальный публичный Android API,
  не reflection и не root. Протокол Joy-Con (подкоманды, формат input report
  `0x30`, калибровка из SPI-флеша) — по открытой реверс-инженерной
  документации dekuNukem (`Nintendo_Switch_Reverse_Engineering`). Реальные
  гироскоп/акселерометр/стики/кнопки приходят как настоящие пакеты по BT.
- **Трекинг камерой**: через `ARFoundation` + `ARTrackedImageManager`
  (ARCore Augmented Images) — реальный, официальный, работающий на
  поддерживаемых Android-устройствах API. Он даёт честную 6DOF-позу
  напечатанного маркера в кадре камеры. Без напечатанного маркера на
  Joy-Con это физически не работает — так и должно быть, это не баг.
- **Слияние сенсоров**: комплементарный фильтр (реальная, проверенная
  практикой техника VR/AR-контроллеров), не имитация — берёт частую,
  но дрейфующую ориентацию с гироскопа Joy-Con и редкую, но абсолютную
  позицию/ориентацию от камеры, взвешенно смешивает.

## Честные ограничения (важно прочитать)

1. **Я не могу собрать вам .apk в этой среде** — здесь нет Unity Editor и
   Android SDK/NDK/Gradle. Вы открываете этот проект в Unity Hub → Unity
   2022 LTS+ → Build Settings → Android → Build. Это последний шаг, который
   должен сделать реальный Unity на вашей машине.
2. **Маркеры обязательны** для трекинга камерой — вы печатаете 2 картинки
   (см. `Assets/StreamingAssets/Markers/`) и клеите на левый и правый
   Joy-Con. Без этого камера не отличит Joy-Con от любого другого предмета —
   никакая "просто камера" библиотека этого без обучения модели не сделает
   честно.
3. **L2CAP-подключение зависит от прошивки Joy-Con и производителя
   Bluetooth-чипа телефона.** Работает стабильно на большинстве устройств
   с Android 10+, но не гарантировано на 100% моделей — это реальность
   недокументированного протокола, а не моя недоработка.
4. Нужен телефон с поддержкой **ARCore** (список: Google "ARCore supported
   devices") для трекинга маркеров, и Android **10 (API 29)+** для L2CAP.
5. Понадобится **Google Cardboard XR Plugin for Unity** (пакет
   `com.google.xr.cardboard`, бесплатный, ставится через Package Manager →
   Add package from git URL) для стерео-рендера в дешёвой VR-оправе. Я не
   переизобретаю стерео-рендер руками — это делает официальный плагин Google.

## Структура

```
Assets/
  Plugins/Android/
    AndroidManifest.xml              # разрешения BLUETOOTH_*, CAMERA
    JoyConPlugin/                    # Android Studio модуль -> собрать в .aar
      src/main/java/.../JoyConBluetoothPlugin.kt
  Scripts/
    JoyCon/
      JoyConManager.cs               # C#-обёртка над .aar, permission runtime
      JoyConData.cs                  # структуры пакетов
    Calibration/
      JoyConCalibration.cs           # чтение заводской калибровки SPI + runtime stationary calibration
      CalibrationUI.cs
    Fusion/
      ComplementaryFilter.cs
      MarkerHandTracker.cs           # ARFoundation Image Tracking
    VR/
      VRHandController.cs
      VRRigSetup.cs
  StreamingAssets/Markers/
    left_joycon_marker.md            # инструкция + требования к маркеру
    right_joycon_marker.md
```

## Порядок сборки .aar плагина (один раз, в Android Studio)

1. Открыть `Assets/Plugins/Android/JoyConPlugin` как проект Android Studio.
2. `Build > Make Module`, забрать `joyconplugin-release.aar` из `build/outputs/aar/`.
3. Положить `.aar` в `Assets/Plugins/Android/` в Unity — Unity сам подхватит
   его в билд.

## Порядок настройки в Unity

1. Package Manager → установить `AR Foundation`, `ARCore XR Plugin`,
   `XR Plugin Management`.
2. Project Settings → XR Plug-in Management → Android → включить ARCore
   (и Cardboard, если добавили пакет).
3. Player Settings → Android → Minimum API Level = 29, Target API актуальный.
4. Создать `XR Reference Image Library`, добавить туда 2 картинки-маркера
   для left/right Joy-Con (см. `StreamingAssets/Markers/*.md`), указать
   реальный физический размер в метрах — критично для точности позы.
5. Собрать сцену: `AR Session`, `AR Session Origin` с `ARTrackedImageManager`
   (Reference Library = ваша библиотека), `AR Camera Manager`.
6. Добавить пустые объекты `LeftHand`, `RightHand`, повесить
   `VRHandController.cs`.
7. Запустить сцену калибровки первой — держим оба Joy-Con неподвижно
   3 секунды для расчёта смещения гироскопа.

Дальше по вашему выбору я пишу конкретные .cs/.kt файлы — они уже в проекте,
но если нужно — углубляю любой модуль (точную математику фильтра, парсинг
конкретных input report, UI калибровки и т.д.).

## CI: сборка .apk через GitHub Actions

Добавлено поверх исходного скелета, чтобы `git push` реально запускал сборку:

- `ProjectSettings/`, `Packages/manifest.json` — раньше их не было вообще (был
  только `Assets/`), т.е. это не открывалось как Unity-проект. Теперь это
  настоящий (минимальный) Unity 2022.3 LTS проект: Android-платформа,
  `minSdkVersion 29`, IL2CPP, ARM64, package id `com.joyconvr.app`.
- `Packages/manifest.json` — добавлены `com.unity.xr.arfoundation`,
  `com.unity.xr.arcore`, `com.unity.xr.management`, `com.unity.ugui` — без них
  `MarkerHandTracker.cs`/`CalibrationUI.cs` не скомпилируются.
- `Assets/Scenes/Main.unity` — пустая сцена (иначе GitHub Actions собирать
  нечего). **Она не настроена** — AR Session, XR Reference Image Library,
  LeftHand/RightHand и т.д. из раздела "Порядок настройки в Unity" выше нужно
  добавить руками в Unity Editor, CI это не подменяет.
- `Assets/Editor/PreBuildCopyUnityClassesJar.cs` — `JoyConPlugin/build.gradle`
  требует `libs/classes.jar` (классы `UnityPlayer`), а этого файла не было в
  архиве — он не хранится в git, а идёт внутри установки Unity. Этот скрипт
  копирует его из Unity Editor прямо перед Android-сборкой (работает и
  локально, и в CI).
- `JoyConPlugin/build.gradle` — добавлен свой `buildscript{}` с classpath на
  Kotlin Gradle Plugin, иначе `apply plugin: 'kotlin-android'` падает: Unity
  не подключает его в корневой Gradle-проект по умолчанию.
- `.github/workflows/build-android.yml` — сборка через `game-ci/unity-builder`.
- **`VRRigSetup.cs`** упоминается в структуре проекта выше, но его не было в
  присланном архиве — компиляции это не мешает (на него никто не ссылается),
  но VR-риг придётся либо написать, либо собрать руками из `VRHandController`.

### Что нужно сделать в GitHub, чтобы workflow заработал

1. Залить этот проект в репозиторий (`git init && git add . && git commit && git push`).
2. Получить **Unity-лицензию для CI** (Personal — бесплатно):
   - Через workflow-помощник `game-ci/unity-request-activation-file`
     (см. https://game.ci/docs/github/activation) — он сгенерирует файл
     `.alf`, который вы загружаете на license.unity3d.com и получаете
     `.ulf`-файл в ответ.
   - Добавить в **Settings → Secrets and variables → Actions** репозитория:
     - `UNITY_LICENSE` — содержимое `.ulf`-файла целиком;
     - `UNITY_EMAIL`, `UNITY_PASSWORD` — от Unity ID (нужны наравне с лицензией).
3. Версия редактора зафиксирована в `ProjectSettings/ProjectVersion.txt`
   (`2022.3.50f1`). Если у вас лицензия/опыт с другой LTS-версией — поменяйте
   строку `m_EditorVersion` там же, `game-ci` сам подтянет нужный образ Unity.
4. (Опционально) подпись релизного APK своим keystore — секреты
   `ANDROID_KEYSTORE_BASE64` (keystore-файл, закодированный в base64),
   `ANDROID_KEYSTORE_PASS`, `ANDROID_KEYALIAS_NAME`, `ANDROID_KEYALIAS_PASS`.
   Без них APK просто собирается debug-подписью Unity — этого достаточно,
   чтобы поставить apk на свой телефон через `adb install`.
5. `git push` → вкладка **Actions** → job "Build for Android" → артефакт
   `JoyConVR-Android-build` с .apk внутри, когда сборка позеленеет.

Первая сборка будет долгой (Unity качает Android SDK/NDK/IL2CPP внутри
Docker-образа) — 15-25 минут это нормально. Дальше `Library` кэшируется
через `actions/cache`, инкрементальные сборки быстрее.
